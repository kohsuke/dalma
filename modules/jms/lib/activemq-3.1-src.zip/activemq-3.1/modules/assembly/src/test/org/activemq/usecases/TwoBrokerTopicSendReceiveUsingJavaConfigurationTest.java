/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.usecases;

import org.activemq.ActiveMQConnectionFactory;
import org.activemq.broker.BrokerContainer;
import org.activemq.broker.impl.BrokerContainerImpl;

import javax.jms.JMSException;

/**
 * @version $Revision: 1.1.1.1 $
 */
public class TwoBrokerTopicSendReceiveUsingJavaConfigurationTest extends TwoBrokerTopicSendReceiveTest {
    BrokerContainer receiveBroker;
    BrokerContainer sendBroker;


    protected ActiveMQConnectionFactory createReceiverConnectionFactory() throws JMSException {
        receiveBroker = new BrokerContainerImpl("receiver");
        receiveBroker.addConnector("tcp://localhost:62002");
        receiveBroker.addNetworkConnector("reliable:tcp://localhost:62001");
        receiveBroker.start();

        ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory(receiveBroker, "tcp://localhost:62002");
        return factory;
    }

    protected ActiveMQConnectionFactory createSenderConnectionFactory() throws JMSException {
        sendBroker = new BrokerContainerImpl("sender");
        sendBroker.addConnector("tcp://localhost:62001");
        sendBroker.addNetworkConnector("reliable:tcp://localhost:62002");
        sendBroker.start();

        ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory(sendBroker, "tcp://localhost:62001");

        return factory;
    }

    protected void tearDown() throws Exception {
        super.tearDown();
        if (sendBroker != null) {
            sendBroker.stop();
        }
        if (receiveBroker != null) {
            receiveBroker.stop();
        }
    }

}
