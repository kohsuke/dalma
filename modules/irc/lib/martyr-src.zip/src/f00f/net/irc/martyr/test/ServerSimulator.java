package f00f.net.irc.martyr.test;

/**
 * The server simulator takes commands in from IRCConnection
 * */
public class ServerSimulator
{
}
