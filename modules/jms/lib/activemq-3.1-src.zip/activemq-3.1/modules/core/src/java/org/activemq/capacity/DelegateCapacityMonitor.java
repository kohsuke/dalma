/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.capacity;
import java.util.Iterator;
import EDU.oswego.cs.dl.util.concurrent.CopyOnWriteArrayList;

/**
 * BasicCapacityMonitor implementation
 * @version $Revision: 1.1.1.1 $
 */
public class DelegateCapacityMonitor implements CapacityMonitor {
    String name;
    CapacityMonitor monitor;
    CopyOnWriteArrayList listeners = new CopyOnWriteArrayList();

    /**
     * Construct a DelegateCapacityMonitor
     * 
     */
    public DelegateCapacityMonitor() {
    }
    
    /**
     * Construct a DelegateCapacityMonitor
     * @param name
     * @param cm
     */
    public DelegateCapacityMonitor(String name,CapacityMonitor cm){
        this.name = name;
        this.monitor = cm;
    }
    
    /**
     * Set the delegated one
     * @param cm
     */
    public void setDelegate(CapacityMonitor cm){
        this.monitor = cm;
        if (cm != null){
            for (Iterator i = listeners.iterator(); i.hasNext();){
                CapacityMonitorEventListener listener = (CapacityMonitorEventListener)i.next();
                cm.addCapacityEventListener(listener);
            }
        }
    }

    /**
     * Get the name of the CapacityMonitor
     * 
     * @return
     */
    public String getName() {
        return name; 
    }
    
    /**
     * @param newName
     */
    public void setName(String newName){
        name = newName;
    }
    
    /**
     * Get the rounding factor - default is 10
     * @return the rounding factor
     */
    public int getRoundingFactor(){
        return monitor == null ? 0 : monitor.getRoundingFactor();
    }
    
    /**
     * Set the rounding factor (between 1-100)
     * @param newRoundingFactor
     */
    public void setRoundingFactor(int newRoundingFactor){
        if(monitor != null){
            monitor.setRoundingFactor(newRoundingFactor);
        }
    }

    /**
     * Add a CapacityEventListener
     * 
     * @param l
     */
    public void addCapacityEventListener(CapacityMonitorEventListener l) {
        listeners.add(l);
        if (monitor != null){
            monitor.addCapacityEventListener(l);
        }
    }

    /**
     * Remove a CapacityEventListener
     * 
     * @param l
     */
    public void removeCapacityEventListener(CapacityMonitorEventListener l) {
        listeners.remove(l);
        if (monitor != null){
            monitor.removeCapacityEventListener(l);
        }
    }

    /**
     * Get the current capscity of the service as a percentage
     * 
     * @return
     */
    public int getCurrentCapacity() {
        return monitor == null ? 100 : monitor.getCurrentCapacity();
    }
    
    /**
     * Calculates the capacity rounded down to the rounding factor
     * @return
     */
    public int getRoundedCapacity(){
        return monitor == null ? 100 : monitor.getRoundedCapacity();
    }

    /**
     * Get the current value of the CapacityMonitor
     * 
     * @return
     */
    public long getCurrentValue() {
        return monitor == null ? 100 : monitor.getCurrentValue();
    }

    /**
     * set the current value of the capacity
     * 
     * @param newCurrentValue
     */
    public void setCurrentValue(long newCurrentValue) {
        if (monitor != null){
            monitor.setCurrentValue(newCurrentValue);
        }
    }

    /**
     * @return The upper limit of the value of the CapacityMonitor
     */
    public long getValueLimit() {
        return monitor == null ? 100 : monitor.getValueLimit();
    }

    /**
     * set a new value limit for the CapacityMonitor
     * 
     * @param newValueLimit
     */
    public void setValueLimit(long newValueLimit) {
        if(monitor != null){
            monitor.setValueLimit(newValueLimit);
        }
        
    }
    
    /**
     * @return a CapacityMontorEvent for the currentCapacity
     */
    public CapacityMonitorEvent generateCapacityMonitorEvent(){
        return monitor != null ? monitor.generateCapacityMonitorEvent() : null;
    }
}
