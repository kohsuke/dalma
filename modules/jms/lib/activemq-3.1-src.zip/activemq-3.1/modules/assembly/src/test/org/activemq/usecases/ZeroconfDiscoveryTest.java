/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.usecases;

import javax.jms.Connection;

import junit.framework.TestCase;

import org.activemq.ActiveMQConnectionFactory;
import org.activemq.spring.SpringBrokerContainerFactory;
import org.springframework.core.io.ClassPathResource;

/**
 * @author Paul Smith
 * @author James Strachan
 * @version $Revision: 1.1.1.1 $
 */
public class ZeroconfDiscoveryTest extends TestCase {

    public void test1() throws Exception {
        ActiveMQConnectionFactory connectionFactory = new ActiveMQConnectionFactory("zeroconf:_activemq.broker.development.");

        // use an embedded broker configured via Spring
        connectionFactory.setUseEmbeddedBroker(true);
        connectionFactory.setBrokerContainerFactory(new SpringBrokerContainerFactory(new ClassPathResource("org/activemq/usecases/receiver-zeroconf.xml")));

        Connection connection = connectionFactory.createConnection();
        connection.setClientID("Producer1");
        connection.start();

        // now lets close things down
        connection.close();
    }
}

