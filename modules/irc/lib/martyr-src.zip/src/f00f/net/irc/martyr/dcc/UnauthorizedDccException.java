package f00f.net.irc.martyr.dcc;

public class UnauthorizedDccException extends DccException
{
	public UnauthorizedDccException( String msg )
	{
		super(msg);
	}
}


