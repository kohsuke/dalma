/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.usecases;
import java.util.HashMap;
import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import org.activemq.ActiveMQConnection;
import org.activemq.ActiveMQConnectionFactory;
import org.activemq.broker.BrokerContainer;
import org.activemq.broker.impl.BrokerContainerImpl;
import org.activemq.test.TestSupport;
import org.activemq.util.IdGenerator;
import EDU.oswego.cs.dl.util.concurrent.SynchronizedBoolean;
import EDU.oswego.cs.dl.util.concurrent.SynchronizedInt;

/**
 * @version $Revision: 1.1.1.1 $
 */
public class ReliableReconnectTest extends TestSupport {
    private static final int RECEIVE_TIMEOUT = 10000;
    protected static final int MESSAGE_COUNT = 100;
    private IdGenerator idGen = new IdGenerator();
    protected int deliveryMode = DeliveryMode.PERSISTENT;
    protected String consumerClientId;
    protected Destination destination;
    protected SynchronizedBoolean closeBroker = new SynchronizedBoolean(false);
    protected SynchronizedInt messagesReceived = new SynchronizedInt(0);
    protected BrokerContainer brokerContainer;
    protected int firstBatch = MESSAGE_COUNT/10;

    public ReliableReconnectTest() {
    }

    public ReliableReconnectTest(String n) {
        super(n);
    }

    protected void setUp() throws Exception {
        consumerClientId = idGen.generateId();
        super.setUp();
        topic = true;
        destination = createDestination(getClass().getName());
    }

    public ActiveMQConnectionFactory getConnectionFactory() throws Exception {
        String url = "reliable:" + ActiveMQConnection.DEFAULT_BROKER_URL;
        return new ActiveMQConnectionFactory(url);
    }

    protected void startBroker() throws JMSException {
        brokerContainer = new BrokerContainerImpl();
        String url = ActiveMQConnection.DEFAULT_BROKER_URL;
        brokerContainer.addConnector(url);
        brokerContainer.start();
    }

    protected Connection createConsumerConnection() throws Exception {
        Connection consumerConnection = getConnectionFactory().createConnection();
        consumerConnection.setClientID(consumerClientId);
        consumerConnection.start();
        return consumerConnection;
    }

    protected MessageConsumer createConsumer(Connection con) throws Exception {
        Session s = con.createSession(false, Session.AUTO_ACKNOWLEDGE);
        return s.createDurableSubscriber((Topic) destination, "TestFred");
    }

    protected void spawnConsumer() {
        Thread thread = new Thread(new Runnable() {
            public void run() {
                try {
                    Connection consumerConnection = createConsumerConnection();
                    MessageConsumer consumer = createConsumer(consumerConnection);
                    //consume some messages
                
                    for (int i = 0;i < firstBatch;i++) {
                        Message msg = consumer.receive(RECEIVE_TIMEOUT);
                        if (msg != null) {
                            //System.out.println("GOT: " + msg);
                            messagesReceived.increment();
                        }
                    }
                    synchronized (closeBroker) {
                        closeBroker.set(true);
                        closeBroker.notify();
                    }
                    Thread.sleep(2000);
                    for (int i = firstBatch;i < MESSAGE_COUNT;i++) {
                        Message msg = consumer.receive(RECEIVE_TIMEOUT);
                        //System.out.println("GOT: " + msg);
                        if (msg != null) {
                            messagesReceived.increment();
                        }
                    }
                    consumerConnection.close();
                    synchronized (messagesReceived) {
                        messagesReceived.notify();
                    }
                }
                catch (Throwable e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
    }

    public void testReconnect() throws Exception {
        startBroker();
        //register an interest as a durable subscriber
        Connection consumerConnection = createConsumerConnection();
        createConsumer(consumerConnection);
        consumerConnection.close();
        //send some messages ...
        Connection connection = createConnection();
        connection.setClientID(idGen.generateId());
        connection.start();
        Session producerSession = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        MessageProducer producer = producerSession.createProducer(destination);
        TextMessage msg = producerSession.createTextMessage();
        for (int i = 0;i < MESSAGE_COUNT;i++) {
            msg.setText("msg: " + i);
            producer.send(msg);
        }
        connection.close();
        spawnConsumer();
        synchronized (closeBroker) {
            if (!closeBroker.get()) {
                closeBroker.wait();
            }
        }
        System.err.println("Stopping broker");
        brokerContainer.stop();
        startBroker();
        System.err.println("Started Broker again");
        synchronized (messagesReceived) {
            if (messagesReceived.get() < MESSAGE_COUNT) {
                messagesReceived.wait(60000);
            }
        }
        //assertTrue(messagesReceived.get() == MESSAGE_COUNT);
        int count = messagesReceived.get();
        assertTrue("Not enough messages received: " + count, count > firstBatch);
    }
}