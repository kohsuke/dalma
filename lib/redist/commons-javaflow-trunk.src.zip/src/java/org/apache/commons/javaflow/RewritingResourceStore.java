/*
 * Copyright 1999-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.javaflow;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import org.apache.bcel.Repository;
import org.apache.bcel.util.ClassLoaderRepository;
import org.apache.commons.javaflow.bytecode.transformation.ClassTransformer;
import org.apache.commons.javaflow.bytecode.transformation.bcel.BcelClassTransformer;
import org.apache.commons.jci.stores.ResourceStore;
import org.apache.commons.jci.stores.TransactionalResourceStore;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * @author tcurdt
 *
 */
public class RewritingResourceStore extends TransactionalResourceStore {

    private final static Log log = LogFactory.getLog(RewritingResourceStore.class);

    private final Collection changes = new ArrayList();
    
    public RewritingResourceStore(final ResourceStore pStore) {
        super(pStore);
        Repository.setRepository(new ClassLoaderRepository(this.getClass().getClassLoader()));
    }

    public void onStart() {
        changes.clear();
    }

    
    public void write(String resourceName, byte[] resourceData) {
        super.write(resourceName, resourceData);
        changes.add(resourceName);
/*
        try {
            final InputStream is = new ByteArrayInputStream(resourceData);

            log.debug("parsing " + resourceName);

            final ClassParser parser = new ClassParser(is, resourceName);
            final JavaClass clazz = parser.parse();
            
            log.debug("saving " + resourceName + " class information in BCEL repository");
            
            Repository.addClass(clazz);
            
        } catch (IOException e) {
            e.printStackTrace();
        }
        */    
    }

    public void onStop() {
        if (changes.size() > 0) {
            log.debug("rewriting"  + changes);
            
            final ClassTransformer transformer = new BcelClassTransformer();
            
            for (Iterator it = changes.iterator(); it.hasNext();) {
                final String clazzName = (String) it.next();
                try {
                    final byte[] oldClazz = read(clazzName);
                    
                    if (oldClazz == null) {
                        throw new ClassNotFoundException("could not find " + clazzName);
                    }
                    
                    final byte[] newClazz = transformer.transform(oldClazz);
                    super.write(clazzName, newClazz);
                    log.debug("rewrote " + clazzName);
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}
