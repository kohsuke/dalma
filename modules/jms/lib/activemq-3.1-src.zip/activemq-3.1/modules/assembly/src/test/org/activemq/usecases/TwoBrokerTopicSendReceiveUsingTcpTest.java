/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.usecases;

import javax.jms.JMSException;

import org.activemq.ActiveMQConnectionFactory;
import org.activemq.broker.BrokerContainer;
import org.activemq.spring.SpringBrokerContainerFactory;
import org.springframework.core.io.ClassPathResource;

/**
 * @version $Revision: 1.1.1.1 $
 */
public class TwoBrokerTopicSendReceiveUsingTcpTest extends TwoBrokerTopicSendReceiveTest {
    private BrokerContainer receiverBroker;
    private BrokerContainer senderBroker;

    protected void setUp() throws Exception {
        receiverBroker = SpringBrokerContainerFactory.newInstance(new ClassPathResource("org/activemq/usecases/receiver.xml"), "receiver");
        senderBroker = SpringBrokerContainerFactory.newInstance(new ClassPathResource("org/activemq/usecases/sender.xml"), "sender");

        receiverBroker.start();
        senderBroker.start();
        super.setUp();
        Thread.sleep(2000);
    }

    protected void tearDown() throws Exception {
        super.tearDown();

        if (receiverBroker != null) {
            receiverBroker.stop();
        }
        if (senderBroker != null) {
            senderBroker.stop();
        }
    }

    
    protected ActiveMQConnectionFactory createReceiverConnectionFactory() throws JMSException {
        ActiveMQConnectionFactory fac =  new ActiveMQConnectionFactory(receiverBroker, "tcp://localhost:62002");
        fac.setUseEmbeddedBroker(false);
        return fac;
    }

    protected ActiveMQConnectionFactory createSenderConnectionFactory() throws JMSException {
        ActiveMQConnectionFactory fac = new ActiveMQConnectionFactory(senderBroker, "tcp://localhost:62001");
        fac.setUseEmbeddedBroker(false);
        return fac;
    }
}
