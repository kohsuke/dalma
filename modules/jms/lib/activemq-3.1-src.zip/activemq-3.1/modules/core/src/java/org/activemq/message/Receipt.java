/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.message;

import java.io.StringWriter;
import java.io.PrintWriter;

/**
 * Sent in receipt of a Packet
 */

public class Receipt extends AbstractPacket {

    private short correlationId;
    private String brokerName;
    private String clusterName;
    private Throwable exception;
    private boolean failed;
    private int brokerMessageCapacity = 100;


    /**
     * @return Returns the jmsException.
     *
     * @Transient
     */
    public Throwable getException() {
        return exception;
    }

    /**
     * @param exception The exception to set.
     */
    public void setException(Throwable exception) {
        this.exception = exception;
    }

    /**
     * Return the type of Packet
     *
     * @return integer representation of the type of Packet
     */

    public int getPacketType() {
        return RECEIPT_INFO;
    }

    /**
     * @return true, this is a receipt packet
     */
    public boolean isReceipt() {
        return true;
    }

    /**
     * @return Returns the correlationId.
     */
    public short getCorrelationId() {
        return this.correlationId;
    }

    /**
     * @param newCorrelationId The correlationId to set.
     */
    public void setCorrelationId(short newCorrelationId) {
        this.correlationId = newCorrelationId;
    }

    /**
     * @return Returns the failed.
     */
    public boolean isFailed() {
        return this.failed;
    }

    /**
     * @param newFailed The failed to set.
     */
    public void setFailed(boolean newFailed) {
        this.failed = newFailed;
    }

    /**
     * @return Returns the brokerMessageCapacity.
     */
    public int getBrokerMessageCapacity() {
        return brokerMessageCapacity;
    }
    /**
     * @param brokerMessageCapacity The brokerMessageCapacity to set.
     */
    public void setBrokerMessageCapacity(int brokerMessageCapacity) {
        this.brokerMessageCapacity = brokerMessageCapacity;
    }
    /**
     * @return Returns the brokerName.
     */
    public String getBrokerName() {
        return brokerName;
    }
    /**
     * @param brokerName The brokerName to set.
     */
    public void setBrokerName(String brokerName) {
        this.brokerName = brokerName;
    }
    /**
     * @return Returns the clusterName.
     */
    public String getClusterName() {
        return clusterName;
    }
    /**
     * @param clusterName The clusterName to set.
     */
    public void setClusterName(String clusterName) {
        this.clusterName = clusterName;
    }

    /**
     * OpenWire helper method
     */
    public String getExceptionAsString() {
        if (exception == null) {
            return null;
        }
        StringWriter buffer = new StringWriter();
        PrintWriter out = new PrintWriter(buffer);
        out.println(exception.getMessage());
        exception.printStackTrace(out);
        out.close();
        return buffer.toString();
    }

    /**
     * OpenWire helper method
     */
    public void setExceptionAsString(String text) {
        Exception answer = null;
        if (text != null && text.length() > 0) {
            answer = new Exception(answer);
        }
        setException(answer);
    }


    /**
     * @return pretty print of a Receipt
     */
    public String toString() {
        return super.toString() + " Receipt{ " +
                "brokerMessageCapacity = " + brokerMessageCapacity +
                ", correlationId = '" + correlationId + "' " +
                ", brokerName = '" + brokerName + "' " +
                ", clusterName = '" + clusterName + "' " +
                ", exception = " + exception +
                ", failed = " + failed +
                " }";
    }
}
