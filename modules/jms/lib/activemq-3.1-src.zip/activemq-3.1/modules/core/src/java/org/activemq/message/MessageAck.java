/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.message;

import org.activemq.service.MessageIdentity;

import java.io.DataInput;
import java.io.IOException;
import java.io.DataOutput;

/**
 * Denotes an object that can be serialized/deserailized using a PacketReader/PacketWriter
 */

public class MessageAck extends AbstractPacket implements BodyPacket{

    public static final int MESSAGE_READ_INDEX = 2;
    public static final int XA_TRANS_INDEX = 3;
    public static final int PERSISTENT_INDEX = 4;
    public static final int EXPIRED_INDEX = 5;
    public static final int TRANSACTION_ID_INDEX = 6;
    public static final int EXTERNAL_MESSAGE_ID_INDEX = 7;
    public static final int CACHED_VALUES_INDEX = 8;
    public static final int LONG_SEQUENCE_INDEX = 9;
    
    private String consumerId;
    private String messageID;
    private ActiveMQDestination  destination;
    private Object transactionId;
    private boolean messageRead;
    private boolean xaTransacted;
    private boolean persistent;
    private boolean expired;
    private short sessionId;
    private long sequenceNumber;
    private String producerKey;
    private boolean externalMessageId;
    private transient MessageIdentity messageIdentity;


    /**
     * Return the type of Packet
     *
     * @return integer representation of the type of Packet
     */

    public int getPacketType() {
        return ACTIVEMQ_MSG_ACK;
    }

    /**
     * @return pretty print of this Packet
     */
    public String toString() {
        return super.toString() + " MessageAck{ " +
                "consumerId = '" + consumerId + "' " +
                ", messageID = '" + messageID + "' " +
                ", destination = " + destination +
                ", transactionId = '" + transactionId + "' " +
                ", messageRead = " + messageRead +
                ", xaTransacted = " + xaTransacted +
                ", persistent = " + persistent +
                ", expired = " + expired +
                ", messageIdentity = " + messageIdentity +
                " }";
    }


    /**
     * @return Returns the transactionId.
     *
     * @Transient
     */
    public Object getTransactionId() {
        return this.transactionId;
    }

    /**
     * @param newTransactionId The transactionId to set.
     *
     * @Transient
     */
    public void setTransactionId(Object newTransactionId) {
        this.transactionId = newTransactionId;
        this.xaTransacted  = newTransactionId!=null && newTransactionId.getClass()==ActiveMQXid.class;
    }


    public void readBody(DataInput dataIn) throws IOException {
        setTransactionIDString(dataIn.readUTF());
    }

    public void writeBody(DataOutput dataOut) throws IOException {
        dataOut.writeUTF(getTransactionIDString());
    }

    /**
     * @return Returns true if this message is part of a transaction
     */

    public boolean isPartOfTransaction() {
        return this.transactionId != null;
    }


    /**
     * @return the messageId
     */
    
    public String getMessageID() {
        if (messageID == null && producerKey != null){
            messageID = producerKey + sequenceNumber;
        }
        return messageID;
    }

    /**
     * @param messageID The messageID to set.
     */
    public void setMessageID(String messageID) {
        this.messageID = messageID;
        this.messageIdentity=null;
    }

    /**
     * @return Returns the messageRead.
     */
    public boolean isMessageRead() {
        return messageRead;
    }

    /**
     * @param messageRead The messageRead to set.
     */
    public void setMessageRead(boolean messageRead) {
        this.messageRead = messageRead;
    }

    /**
     * @return Returns the consumerId.
     */
    public String getConsumerId() {
        return consumerId;
    }

    /**
     * @param consumerId The consumerId to set.
     */
    public void setConsumerId(String consumerId) {
        this.consumerId = consumerId;
    }

    /**
     * @return Returns the xaTransacted.
     */
    public boolean isXaTransacted() {
        return xaTransacted;
    }

    public MessageIdentity getMessageIdentity() {
        if (messageIdentity == null) {
            messageIdentity = new MessageIdentity(getMessageID());
        }
        return messageIdentity;
    }
    /**
     * @return Returns the destination.
     */
    public ActiveMQDestination getDestination() {
        return destination;
    }
    /**
     * @param destination The destination to set.
     */
    public void setDestination(ActiveMQDestination destination) {
        this.destination = destination;
    }
    /**
     * @return Returns the persistent.
     */
    public boolean isPersistent() {
        return persistent;
    }
    /**
     * @param persistent The persistent to set.
     */
    public void setPersistent(boolean persistent) {
        this.persistent = persistent;
    }
    
    /**
     * @return true the delivered message was to a non-persistent destination
     */
    public boolean isTemporary(){
        return persistent == false || (destination != null && destination.isTemporary());
    }
    
    /**
     * @return Returns the expired.
     */
    public boolean isExpired() {
        return expired;
    }
    /**
     * @param expired The expired to set.
     */
    public void setExpired(boolean expired) {
        this.expired = expired;
    }
    
    /**
     * @return Returns the producerKey.
     */
    public String getProducerKey() {
        return producerKey;
    }
    /**
     * @param producerKey The producerKey to set.
     */
    public void setProducerKey(String producerKey) {
        this.producerKey = producerKey;
    }
    
    /**
     * @return Returns the messageSequence.
     */
    public long getSequenceNumber() {
        return sequenceNumber;
    }
    /**
     * @param messageSequence The messageSequence to set.
     */
    public void setSequenceNumber(long messageSequence) {
        this.sequenceNumber = messageSequence;
    }
    /**
     * @return Returns the sessionId.
     */
    public short getSessionId() {
        return sessionId;
    }
    /**
     * @param sessionId The sessionId to set.
     */
    public void setSessionId(short sessionId) {
        this.sessionId = sessionId;
    }
    /**
     * @return Returns the externalMessageId.
     */
    public boolean isExternalMessageId() {
        return externalMessageId;
    }
    /**
     * @param externalMessageId The externalMessageId to set.
     */
    public void setExternalMessageId(boolean externalMessageId) {
        this.externalMessageId = externalMessageId;
    }

    /**
     * A helper method for the OpenWire protocol
     */
    public String getTransactionIDString() throws IOException {
        return ActiveMQXid.transactionIDToString(getTransactionId());
    }

    /**
     * A helper method for the OpenWire protocol
     */
    public void setTransactionIDString(String text) throws IOException {
        setTransactionId(ActiveMQXid.transactionIDFromString(text));
    }
}
