/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.jca;

import javax.resource.spi.BootstrapContext;

/**
 * This is a JCAContainer which is similar to the {@link JCAContainer} implementation
 * but this implementation takes a {@link BootstrapContext} property.
 *
 * @version $Revision: 1.1 $
 */
public class JCAContainerWithBootstrap extends JCAContainerSupport {
    private BootstrapContext bootstrapContext;

    public void afterPropertiesSet() throws Exception {
        if (bootstrapContext == null) {
            throw new IllegalArgumentException("bootstrapContext property must be set");
        }
        super.afterPropertiesSet();
    }

    public BootstrapContext getBootstrapContext() {
        return bootstrapContext;
    }

    public void setBootstrapContext(BootstrapContext bootstrapContext) {
        this.bootstrapContext = bootstrapContext;
    }
}
