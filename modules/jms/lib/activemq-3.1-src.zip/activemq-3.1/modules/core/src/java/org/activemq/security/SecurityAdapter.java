/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.security;

import org.activemq.broker.BrokerClient;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ConnectionInfo;
import org.activemq.message.ConsumerInfo;
import org.activemq.message.ProducerInfo;

import javax.jms.JMSException;

/**
 * A pluggable strategy to authenticate new connections and authorize
 * the connection and producer and consumer on destinations
 *
 * @version $Revision: 1.1.1.1 $
 */
public interface SecurityAdapter {

    /**
     * Authenticates the connection and authorizes it for use with this
     * Message Broker
     *
     * @throws JMSException if the connection is not allowed for any reason
     */
    public void authorizeConnection(BrokerClient client, ConnectionInfo info) throws JMSException;

    /**
     * Authorizes that the consumer can start with the given consumer information
     *
     * @throws JMSException if the connection is not allowed for any reason
     */
    public void authorizeConsumer(BrokerClient client, ConsumerInfo info) throws JMSException;

    /**
     * Authorizes that the prodcuer can start with the given producer information.
     * Note that the destination information may not be present at the start of the producer.
     *
     * @throws JMSException if the connection is not allowed for any reason
     */
    public void authorizeProducer(BrokerClient client, ProducerInfo info) throws JMSException;

    /**
     * Authorizes on a per message basis whether or not the client is allowed to send the given
     * message. The client may not have been authorized yet for this destination as a destination
     * may not have been specified on the previous call to
     * {@link #authorizeProducer(org.activemq.broker.BrokerClient, org.activemq.message.ProducerInfo)}
     */
    public void authorizeSendMessage(BrokerClient client, ActiveMQMessage message) throws JMSException;

    /**
     * Returns true if the given client is authorized to receive the given message.
     *
     * @param client the client
     * @param message the message to be delivered
     * @return true if the client can receive the given message
     */
    public boolean authorizeReceive(BrokerClient client, ActiveMQMessage message);
}
