/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.message;

/**
 * Denotes an object that can be serialized/deserailized using a Packet Reader/Writer
 */

public class CleanupConnectionInfo extends AbstractPacket {

    private String clientId;
    private short sessionId;

    /**
     * Return the type of Packet
     *
     * @return integer representation of the type of Packet
     */

    public int getPacketType() {
        return CLEANUP_CONNECTION_INFO;
    }


    /**
     * Test for equality
     *
     * @param obj object to test
     * @return true if equivalent
     */
    public boolean equals(Object obj) {
        boolean result = false;
        if (obj != null && obj instanceof CleanupConnectionInfo) {
            CleanupConnectionInfo info = (CleanupConnectionInfo) obj;
            result = this.clientId.equals(info.clientId) && this.sessionId == info.sessionId;
        }
        return result;
    }

    /**
     * @return hash code for instance
     */
    public int hashCode() {
        if (cachedHashCode == -1){
            String hashCodeStr = clientId + sessionId;
            cachedHashCode = hashCodeStr.hashCode();
        }
        return cachedHashCode;
    }
    


    /**
     * @return Returns the sessionId.
     */
    public short getSessionId() {
        return sessionId;
    }

    /**
     * @param sessionId The sessionId to set.
     */
    public void setSessionId(short sessionId) {
        this.sessionId = sessionId;
    }


    /**
     * @return Returns the clientId.
     */
    public String getClientId() {
        return this.clientId;
    }

    /**
     * @param newClientId The clientId to set.
     */
    public void setClientId(String newClientId) {
        this.clientId = newClientId;
    }

    public String toString() {
        return super.toString() + " ClenaupConnectionAndSessionInfo{ " +
                "clientId = '" + clientId + "' " +
                ", sessionId = '" + sessionId + "' " +
                " }";
    }
}
