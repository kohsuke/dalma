/**
 *
 * Copyright 2004 Protique Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **/

package org.activemq.io.impl;
import java.io.DataOutput;
import java.io.IOException;
import org.activemq.message.Packet;
import org.activemq.message.TransactionType;
import org.activemq.message.XATransactionInfo;

/**
 * Writes a TransactionInfo object to a Stream
 */

public class XATransactionInfoWriter extends AbstractPacketWriter {

    /**
     * Return the type of Packet
     *
     * @return integer representation of the type of Packet
     */

    public int getPacketType() {
        return Packet.XA_TRANSACTION_INFO;
    }

    /**
     * Write a Packet instance to data output stream
     *
     * @param packet  the instance to be seralized
     * @param dataOut the output stream
     * @throws java.io.IOException thrown if an error occurs
     */

    public void writePacket(Packet packet, DataOutput dataOut) throws IOException {
        super.writePacket(packet, dataOut);
        XATransactionInfo info = (XATransactionInfo) packet;
        dataOut.writeByte(info.getType());
        switch (info.getType()) {
            case TransactionType.START:
            case TransactionType.PRE_COMMIT:
            case TransactionType.COMMIT:
            case TransactionType.RECOVER:
            case TransactionType.ROLLBACK:
            case TransactionType.END:
            case TransactionType.FORGET:
            case TransactionType.JOIN:
            case TransactionType.COMMIT_ONE_PHASE:
                assert info.getXid() != null;
                info.getXid().write(dataOut);
                break;
            case TransactionType.SET_TX_TIMEOUT:
                dataOut.writeInt(info.getTransactionTimeout());
                break;
            case TransactionType.XA_RECOVER:
                //recover should take a flag.
                break;
            case TransactionType.GET_TX_TIMEOUT:
            case TransactionType.GET_RM_ID:
                break;
            default:
                throw new IllegalArgumentException("Invalid type code: " + info.getType());
        }
    }

}
