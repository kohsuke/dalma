/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.transport;

import junit.framework.TestCase;

import org.activemq.transport.jrms.JRMSTransportChannelFactory;
import org.activemq.transport.jrms.JRMSTransportServerChannelFactory;
import org.activemq.transport.multicast.MulticastTransportChannelFactory;
import org.activemq.transport.multicast.MulticastTransportServerChannelFactory;
import org.activemq.transport.ssl.SslTransportChannelFactory;
import org.activemq.transport.ssl.SslTransportServerChannelFactory;
import org.activemq.transport.tcp.TcpTransportChannelFactory;
import org.activemq.transport.tcp.TcpTransportServerChannelFactory;
import org.activemq.transport.udp.UdpTransportChannelFactory;
import org.activemq.transport.udp.UdpTransportServerChannelFactory;
import org.activemq.transport.vm.VmTransportChannelFactory;
import org.activemq.transport.vm.VmTransportServerChannelFactory;
import org.activemq.util.FactoryFinder;

/**
 * @version $Revision: 1.2 $
 */
public class FactoryFinderTest extends TestCase {
    FactoryFinder clientFinder = new FactoryFinder("META-INF/services/org/activemq/transport/");
    FactoryFinder serverFinder = new FactoryFinder("META-INF/services/org/activemq/transport/server/");

    public void testClientFactory() throws Exception {
        assertClient("jrms", JRMSTransportChannelFactory.class);
        assertClient("multicast", MulticastTransportChannelFactory.class);
        assertClient("ssl", SslTransportChannelFactory.class);
        assertClient("tcp", TcpTransportChannelFactory.class);
        assertClient("udp", UdpTransportChannelFactory.class);
        assertClient("vm", VmTransportChannelFactory.class);
//        assertClient("jxta", JxtaTransportChannelFactory.class);
//        assertClient("nio", EmberTransportChannelFactory.class);
    }

    public void testServerFactory() throws Exception {
        assertServer("jrms", JRMSTransportServerChannelFactory.class);
        assertServer("multicast", MulticastTransportServerChannelFactory.class);
        assertServer("ssl", SslTransportServerChannelFactory.class);
        assertServer("tcp", TcpTransportServerChannelFactory.class);
        assertServer("udp", UdpTransportServerChannelFactory.class);
        assertServer("vm", VmTransportServerChannelFactory.class);
//        assertServer("jxta", JxtaTransportServerChannelFactory.class);
//        assertServer("nio", EmberTransportServerChannelFactory.class);
    }

    protected void assertClient(String key, Class type) throws Exception {
        assertFinder(key, type, clientFinder);
    }

    protected void assertServer(String key, Class type) throws Exception {
        assertFinder(key, type, serverFinder);
    }

    protected void assertFinder(String key, Class type, FactoryFinder finder) throws Exception {
        Object factory = finder.newInstance(key);
        assertTrue("Returned non null object", factory != null);
        assertTrue("Is an instance of: " + type, type.isInstance(factory));

        // lets do it one more time to test the cache returns the same value
        factory = finder.newInstance(key);
        assertTrue("Is an instance of: " + type, type.isInstance(factory));
    }
}
