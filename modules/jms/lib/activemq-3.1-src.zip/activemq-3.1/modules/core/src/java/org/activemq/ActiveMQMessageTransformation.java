/**
 *
 * Copyright 2004 Protique Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **/
package org.activemq;

import org.activemq.message.*;

import javax.jms.*;
import java.util.Enumeration;


/**
 * Transforms foreign Destinations and Messages to ActiveMQ formats
 *
 * @version $Revision: 1.1.1.1 $
 */
class ActiveMQMessageTransformation {
    /**
     * @param destination
     * @return an ActiveMQDestination
     * @throws JMSException if an error occurs
     */
    static ActiveMQDestination transformDestination(Destination destination) throws JMSException {
        ActiveMQDestination result = null;
        if (destination != null) {
            if (destination instanceof ActiveMQDestination) {
                result = (ActiveMQDestination) destination;
            }
            else {
                if (destination instanceof TemporaryQueue) {
                    result = new ActiveMQTemporaryQueue(((Queue) destination).getQueueName());
                }
                else if (destination instanceof TemporaryTopic) {
                    result = new ActiveMQTemporaryTopic(((Topic) destination).getTopicName());
                }
                else if (destination instanceof Queue) {
                    result = new ActiveMQQueue(((Queue) destination).getQueueName());
                }
                else if (destination instanceof Topic) {
                    result = new ActiveMQTopic(((Topic) destination).getTopicName());
                }
            }
        }
        return result;
    }

    /**
     * Creates a fast shallow copy of the current ActiveMQMessage or creates a whole new
     * message instance from an available JMS message from another provider.
     *
     * @param message
     * @return an ActiveMQMessage
     * @throws JMSException if an error occurs
     */
    public static final ActiveMQMessage transformMessage(Message message) throws JMSException {
        if (message instanceof ActiveMQMessage) {
            return (ActiveMQMessage)message;
        }
        else {
            ActiveMQMessage activeMessage = null;
            if (message instanceof ObjectMessage) {
                ObjectMessage objMsg = (ObjectMessage) message;
                ActiveMQObjectMessage msg = new ActiveMQObjectMessage();
                msg.setObject(objMsg.getObject());
                activeMessage = msg;
            }
            else if (message instanceof TextMessage) {
                TextMessage textMsg = (TextMessage) message;
                ActiveMQTextMessage msg = new ActiveMQTextMessage();
                msg.setText(textMsg.getText());
                activeMessage = msg;
            }
            else if (message instanceof MapMessage) {
                MapMessage mapMsg = (MapMessage) message;
                ActiveMQMapMessage msg = new ActiveMQMapMessage();
                for (Enumeration iter = mapMsg.getMapNames(); iter.hasMoreElements();) {
                    String name = iter.nextElement().toString();
                    msg.setObject(name, mapMsg.getObject(name));
                }
                activeMessage = msg;
            }
            else if (message instanceof BytesMessage) {
                BytesMessage bytesMsg = (BytesMessage) message;
                bytesMsg.reset();
                ActiveMQBytesMessage msg = new ActiveMQBytesMessage();
                try {
                    for (; ;) {
                        msg.writeByte(bytesMsg.readByte());
                    }
                }
                catch (JMSException e) {
                }
                activeMessage = msg;
            }
            else if (message instanceof StreamMessage) {
                StreamMessage streamMessage = (StreamMessage) message;
                streamMessage.reset();
                ActiveMQStreamMessage msg = new ActiveMQStreamMessage();
                Object obj = null;
                try {
                    while ((obj = streamMessage.readObject()) != null) {
                        msg.writeObject(obj);
                    }
                }
                catch (JMSException e) {
                }
                activeMessage = msg;
            }
            else {
                activeMessage = new ActiveMQMessage();
            }
            activeMessage.setJMSMessageID(message.getJMSMessageID());
            activeMessage.setJMSCorrelationID(message.getJMSCorrelationID());
            activeMessage.setJMSReplyTo(transformDestination(message.getJMSReplyTo()));
            activeMessage.setJMSDestination(transformDestination(message.getJMSDestination()));
            activeMessage.setJMSDeliveryMode(message.getJMSDeliveryMode());
            activeMessage.setJMSRedelivered(message.getJMSRedelivered());
            activeMessage.setJMSType(message.getJMSType());
            activeMessage.setJMSExpiration(message.getJMSExpiration());
            activeMessage.setJMSPriority(message.getJMSPriority());
            activeMessage.setJMSTimestamp(message.getJMSTimestamp());
            for (Enumeration propertyNames = message.getPropertyNames(); propertyNames.hasMoreElements();) {
                String name = propertyNames.nextElement().toString();
                Object obj = message.getObjectProperty(name);
                activeMessage.setObjectProperty(name, obj);
            }
            return activeMessage;
        }
    }
}
