/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.config;

import org.activemq.broker.BrokerClient;
import org.activemq.message.ActiveMQMessage;
import org.activemq.message.ConnectionInfo;
import org.activemq.message.ConsumerInfo;
import org.activemq.message.ProducerInfo;
import org.activemq.security.SecurityAdapter;

import javax.jms.JMSException;

/**
 * @version $Revision: 1.1.1.1 $
 */
public class SecurityAdapterStub implements SecurityAdapter {

    public void authorizeConnection(BrokerClient client, ConnectionInfo info) throws JMSException {
    }

    public void authorizeConsumer(BrokerClient client, ConsumerInfo info) throws JMSException {
    }

    public void authorizeProducer(BrokerClient client, ProducerInfo info) throws JMSException {
    }

    public void authorizeSendMessage(BrokerClient client, ActiveMQMessage message) throws JMSException {
    }

    public boolean authorizeReceive(BrokerClient client, ActiveMQMessage message) {
        return true;
    }
}
