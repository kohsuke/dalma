package org.activemq.usecases;

public class QueueSystemTest extends SystemTest {

    /**
     * Sets up the resources of the unit test.
     *
     * @throws Exception
     */
    protected void setUp() throws Exception {
        System.out.println("############################################################");
        System.out.println("QueueSystemTest.setUp()...");
        super.setUp();
    }

    /**
     * Clears up the resources used in the unit test.
     */
    protected void tearDown() throws Exception {
        System.out.println("QueueSystemTest.tearDown()...");
        System.out.println("############################################################");
        super.tearDown();
    }

    /**
     * Unit test for persistent queue messages with the following settings:
     * 1 Producer, 1 Consumer, 1 Subject, 10 Messages
     *
     * @throws Exception
     */
    ///*
    public void testPersistentQueueMessageA() throws Exception{
        SystemTest st = new SystemTest(false,
                                       true,
                                       false,
                                       1,
                                       1,
                                       1,
                                       10,
                                       "testPersistentQueueMessageA()");
        st.doTest();
    }
    //*/

    /**
     * Unit test for persistent queue messages with the following settings:
     * 10 Producers, 10 Consumers, 1 Subject, 10 Messages
     *
     * @throws Exception
     */
    /*
    public void testPersistentQueueMessageB() throws Exception{
        SystemTest st = new SystemTest(false,
                                       true,
                                       false,
                                       10,
                                       10,
                                       1,
                                       10,
                                       "testPersistentQueueMessageB()");
        st.doTest();
    }
    */

    /**
     * Unit test for persistent queue messages with the following settings:
     * 10 Producers, 10 Consumers, 10 Subjects, 10 Messages
     *
     * @throws Exception
     */
    /*
    public void testPersistentQueueMessageC() throws Exception{
        SystemTest st = new SystemTest(false,
                                       true,
                                       false,
                                       10,
                                       10,
                                       10,
                                       10,
                                       "testPersistentQueueMessageC()");
        st.doTest();
    }
    */

    /**
     * Unit test for non-persistent queue messages with the following settings:
     * 1 Producer, 1 Consumer, 1 Subject, 10 Messages
     *
     * @throws Exception
     */
    /*
    public void testNonPersistentQueueMessageA() throws Exception {
        SystemTest st = new SystemTest(false,
                                       false,
                                       false,
                                       1,
                                       1,
                                       1,
                                       10,
                                       "testNonPersistentQueueMessageA()");
        st.doTest();
    }
    */

    /**
     * Unit test for non-persistent queue messages with the following settings:
     * 10 Producers, 10 Consumers, 1 Subject, 10 Messages
     *
     * @throws Exception
     */
    /*
    public void testNonPersistentQueueMessageB() throws Exception{
        SystemTest st = new SystemTest(false,
                                       false,
                                       false,
                                       10,
                                       10,
                                       1,
                                       10,
                                       "testNonPersistentQueueMessageB()");
        st.doTest();
    }
    */

    /**
     * Unit test for non-persistent queue messages with the following settings:
     * 10 Producers, 10 Consumers, 10 Subjects, 10 Messages
     *
     * @throws Exception
     */
    /*
    public void testNonPersistentQueueMessageC() throws Exception{
        SystemTest st = new SystemTest(false,
                                       false,
                                       false,
                                       10,
                                       10,
                                       10,
                                       10,
                                       "testNonPersistentQueueMessageC()");
        st.doTest();
    }
    */
}