/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.bean;

import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageConsumer;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import java.io.Serializable;

/**
 * A helper base class POJO which can be used by any POJO deployed
 * in the JMS container.
 * <p/>
 * This POJO supports both container based and setter based injection.
 *
 * @version $Revision: 1.1.1.1 $
 */
public class JmsHelper {
    private Session session;
    private MessageProducer producer;
    private long defaultTimeout = 5000L;

    public JmsHelper() {
    }

    public JmsHelper(Session session, MessageProducer producer) {
        this.session = session;
        this.producer = producer;
    }

    public void send(Destination destination, Message message) throws JMSException {
        producer.send(destination, message);
    }

    public void send(Message message) throws JMSException {
        producer.send(message);
    }

    public void send(String subject, Message message, boolean isTopic) throws JMSException {
        Destination destination = null;
        if (isTopic) {
            destination = session.createTopic(subject);
        }
        else {
            destination = session.createQueue(subject);
        }
        send(destination, message);
    }


    /**
     * Performs an RPC to the given destination - blocking
     * until a reply is received up to the given timeout
     *
     * @param destination
     * @param request
     * @return
     */
    public Message call(Destination destination, Message request, long timeout) throws JMSException {
        // TODO : we could improve performance by caching the consumer and temporary queue
        // and using a correlation ID to ensure that responses match requests etc

        Destination tempDest = null;
        if (destination instanceof Topic) {
            tempDest = session.createTemporaryTopic();
        }
        else {
            tempDest = session.createTemporaryQueue();
        }
        MessageConsumer consumer = session.createConsumer(tempDest);
        Message answer = consumer.receive(timeout);
        consumer.close();
        return answer;
    }

    /**
     * Performs an RPC to the given destination - blocking
     * until a reply is received up to some maximum timeout
     *
     * @param destination
     * @param request
     * @return
     */
    public Message call(Destination destination, Message request) throws JMSException {
        return call(destination, request, defaultTimeout);
    }

    // Some helper factory methods

    public TextMessage createTextMessage(String text) throws JMSException {
        return session.createTextMessage(text);
    }

    public ObjectMessage createObjectMessage(Serializable object) throws JMSException {
        return session.createObjectMessage(object);
    }


    // Properties

    public Session getSession() {
        return session;
    }

    public void setSession(Session session) {
        this.session = session;
    }

    public MessageProducer getProducer() {
        return producer;
    }

    public void setProducer(MessageProducer producer) {
        this.producer = producer;
    }

    public long getDefaultTimeout() {
        return defaultTimeout;
    }

    public void setDefaultTimeout(long defaultTimeout) {
        this.defaultTimeout = defaultTimeout;
    }

}
