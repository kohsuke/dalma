/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.advisories;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

import org.activemq.message.AbstractPacket;
import org.activemq.message.ActiveMQDestination;

/**
 * This event is raised when a MessageTempDestination starts/stops *
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class TempDestinationAdvisoryEvent extends AbstractPacket implements Externalizable {

    private static final long serialVersionUID = -541770480868770950L;
    
    private ActiveMQDestination destination;
    private boolean started;

    /**
     * Empty constructor
     */
    public TempDestinationAdvisoryEvent() {
    }

    /**
     * Default Constructor
     * 
     * @param dest
     * @param started
     */
    public TempDestinationAdvisoryEvent(ActiveMQDestination dest, boolean started) {
        this.destination = dest;
        this.started = started;
    }

    /**
     * @return Returns the destination.
     */
    public ActiveMQDestination getDestination() {
        return destination;
    }

    /**
     * @param destination The destination to set.
     */
    public void setDestination(ActiveMQDestination destination) {
        this.destination = destination;
    }

    /**
     * @return Returns the started.
     */
    public boolean isStarted() {
        return started;
    }

    /**
     * @param started The started to set.
     */
    public void setStarted(boolean started) {
        this.started = started;
    }

    /**
     * write to a stream
     * 
     * @param out
     * @throws IOException
     */
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeBoolean(this.started);
        ActiveMQDestination.writeToStream(getDestination(), out);
    }

    /**
     * read from a stream
     * 
     * @param in
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        this.started = in.readBoolean();
        this.destination = ActiveMQDestination.readFromStream(in);
    }

    /**
     * @param obj
     * @return true if obj is equal
     */
    public boolean equals(Object obj) {
        boolean result = false;
        if (obj != null && obj instanceof TempDestinationAdvisoryEvent) {
            TempDestinationAdvisoryEvent event = (TempDestinationAdvisoryEvent) obj;
            result = destination != null && event.destination != null && destination.equals(event.destination);
        }
        return result;
    }

    /**
     * @return hash code
     */
    public int hashCode() {
        return destination != null ? destination.hashCode() : super.hashCode();
    }

    /**
     * @return Packet type - for this case -1
     */
    public int getPacketType() {
        return -1;
    }

    /**
     * @return pretty print of 'this'
     */
    public String toString() {
        String str = "TempDestinationAdvisoryEvent: " + destination + " has " + (started ? "started" : "stopped");
        return str;
    }
}