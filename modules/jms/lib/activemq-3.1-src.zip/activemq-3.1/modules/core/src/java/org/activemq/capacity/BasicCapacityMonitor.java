/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.capacity;
import java.util.Iterator;
import EDU.oswego.cs.dl.util.concurrent.CopyOnWriteArrayList;

/**
 * BasicCapacityMonitor implementation
 * @version $Revision: 1.1.1.1 $
 */
public class BasicCapacityMonitor implements CapacityMonitor {
    private String name;
    private long valueLimit;
    private long currentValue = 0;
    private int currentCapacity = 100;
    private int roundedCapacity = 100;
    private int roundingFactor = 10;
    private CopyOnWriteArrayList listeners = new CopyOnWriteArrayList();

    /**
     * Construct a CapacityMonitor
     * 
     * @param name
     * @param valueLimit
     */
    public BasicCapacityMonitor(String name, long valueLimit) {
        this.name = name;
        this.valueLimit = valueLimit;
    }

    /**
     * Get the name of the CapacityMonitor
     * 
     * @return
     */
    public String getName() {
        return name;
    }
    
    /**
     * @param newName
     */
    public void setName(String newName){
        name = newName;
    }
    
    /**
     * Get the rounding factor - default is 10
     * @return the rounding factor
     */
    public int getRoundingFactor(){
        return roundingFactor;
    }
    
    /**
     * Set the rounding factor (between 1-100)
     * @param newRoundingFactor
     */
    public void setRoundingFactor(int newRoundingFactor){
        if (newRoundingFactor < 1 || newRoundingFactor > 100){
            throw new IllegalArgumentException("invalid roundingFactor: " + newRoundingFactor);
        }
        roundingFactor = newRoundingFactor;
    }

    /**
     * Add a CapacityMonitorEventListener
     * 
     * @param l
     */
    public void addCapacityEventListener(CapacityMonitorEventListener l) {
        listeners.add(l);
    }

    /**
     * Remove a CapacityMonitorEventListener
     * 
     * @param l
     */
    public void removeCapacityEventListener(CapacityMonitorEventListener l) {
        listeners.remove(l);
    }

    /**
     * Get the current capscity of the service as a percentage
     * 
     * @return
     */
    public int getCurrentCapacity() {
        return currentCapacity;
    }
    
    /**
     * Calculates the capacity rounded down to the rounding factor
     * @return
     */
    public int getRoundedCapacity(){
        return roundedCapacity;
    }

    /**
     * Get the current value of the CapacityMonitor
     * 
     * @return
     */
    public long getCurrentValue() {
        return currentValue;
    }

    /**
     * set the current value of the capacity
     * 
     * @param newCurrentValue
     */
    public void setCurrentValue(long newCurrentValue) {
        currentValue = newCurrentValue;
        int newCapacity = calculateCapacity();
        int newRoundedCapacity = newCapacity > 0 ?  (newCapacity/roundingFactor)*roundingFactor : 0;
        updateCapacityChanged(newRoundedCapacity);
        currentCapacity = newCapacity;
        roundedCapacity = newRoundedCapacity;
    }

    /**
     * @return The upper limit of the value of the CapacityMonitor
     */
    public long getValueLimit() {
        return valueLimit;
    }

    /**
     * set a new value limit for the CapacityMonitor
     * 
     * @param newValueLimit
     */
    public void setValueLimit(long newValueLimit) {
        valueLimit = newValueLimit;
        //this could have changed the capacity
        setCurrentValue(currentValue);
        
    }
    
    /**
     * @return a CapacityMontorEvent for the currentCapacity
     */
    public CapacityMonitorEvent generateCapacityMonitorEvent(){
        CapacityMonitorEvent event = new CapacityMonitorEvent(name, roundedCapacity);
        return event;
    }

    private void updateCapacityChanged(int newRoundedCapacity) {
        if (listeners.size() > 0 && newRoundedCapacity != roundedCapacity) {
            CapacityMonitorEvent event = new CapacityMonitorEvent(name, newRoundedCapacity);
            for (Iterator i = listeners.iterator();i.hasNext();) {
                CapacityMonitorEventListener listener = (CapacityMonitorEventListener) i.next();
                listener.capacityChanged(event);
            }
        }
        
    }

    private int calculateCapacity() {
        int result = 100;
        if (currentValue != 0){
            result = (int) (100-(currentValue * 100)/valueLimit);
        }
        return result;
    }
}
