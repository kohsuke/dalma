/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.jca;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;

import javax.resource.spi.BootstrapContext;
import javax.resource.spi.ResourceAdapter;

/**
 * @version $Revision: 1.1 $
 */
public abstract class JCAContainerSupport implements InitializingBean, DisposableBean, BeanFactoryAware {
    private static final transient Log log = LogFactory.getLog(JCAContainerSupport.class);

    protected ResourceAdapter resourceAdapter;
    private BeanFactory beanFactory;
    private boolean lazyLoad = false;


    public JCAConnector addConnector() {
        return new JCAConnector(getBootstrapContext(), getResourceAdapter());
    }

    public void afterPropertiesSet() throws Exception {
        if (resourceAdapter == null) {
            throw new IllegalArgumentException("bootstrapContext must be set");

        }
        resourceAdapter.start(getBootstrapContext());

        // now lets start all of the JCAConnector instances
        if (beanFactory == null) {
            throw new IllegalArgumentException("beanFactory should have been set by Spring");
        }
        else if (!lazyLoad && beanFactory instanceof BeanDefinitionRegistry) {
            BeanDefinitionRegistry registry = (BeanDefinitionRegistry) beanFactory;
            String[] names = registry.getBeanDefinitionNames();
            for (int i = 0; i < names.length; i++) {
                // TODO one day we could be smart to only pre-load the correct
                // types of bean, based on the definitions?
                String name = names[i];
                BeanDefinition definition = registry.getBeanDefinition(name);
                if (!definition.isAbstract()) {
                    beanFactory.getBean(name);
                }
            }
        }

        String version = null;
        Package aPackage = Package.getPackage("org.activemq.jca");
        if (aPackage != null) {
            version = aPackage.getImplementationVersion();
        }

        log.info("ActiveMQ JCA Container (http://activemq.org/) has started running version: " + version);
    }

    public void destroy() throws Exception {
        if (resourceAdapter != null) {
            resourceAdapter.stop();
        }
    }


    // Properties
    //-------------------------------------------------------------------------
    public BeanFactory getBeanFactory() {
        return beanFactory;
    }

    public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
        this.beanFactory = beanFactory;
    }

    public ResourceAdapter getResourceAdapter() {
        return resourceAdapter;
    }

    public void setResourceAdapter(ResourceAdapter resourceAdapter) {
        this.resourceAdapter = resourceAdapter;
    }

    public boolean isLazyLoad() {
        return lazyLoad;
    }

    public void setLazyLoad(boolean lazyLoad) {
        this.lazyLoad = lazyLoad;
    }

    // Implementation methods
    //-------------------------------------------------------------------------
    protected abstract BootstrapContext getBootstrapContext();
}
