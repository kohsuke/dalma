This module contains a lightweight embeddable Spring based JCA Container

This container can be used to consume JMS messages using regular POJOs using
Spring along with commons-pool based pooling.

In addition a collection of helper classes are included to perform common
operations such as bridging JMS providers