package org.activemq.usecases;

public class PersistentNonDurableTopicSystemTest extends SystemTest {

    /**
     * Sets up the resources of the unit test.
     *
     * @throws Exception
     */
    protected void setUp() throws Exception {
        System.out.println("############################################################");
        System.out.println("PersistentNonDurableTopicSystemTest.setUp()...");
        super.setUp();
    }

    /**
     * Clears up the resources used in the unit test.
     */
    protected void tearDown() throws Exception {
        System.out.println("PersistentNonDurableTopicSystemTest.tearDown()...");
        System.out.println("############################################################");
        super.tearDown();
    }

    /**
     * Unit test for persistent non-durable topic messages with the following settings:
     * 1 Producer, 1 Consumer, 1 Subject, 10 Messages
     *
     * @throws Exception
     */
    public void testPersistentNonDurableTopicMessageA() throws Exception{
        SystemTest st = new SystemTest(true,
                                       true,
                                       false,
                                       1,
                                       1,
                                       1,
                                       10,
                                       "testPersistentNonDurableTopicMessageA()");
        st.doTest();
    }

    /**
     * Unit test for persistent non-durable topic messages with the following settings:
     * 10 Producers, 10 Consumers, 1 Subject, 10 Messages
     *
     * @throws Exception
     */
    public void testPersistentNonDurableTopicMessageB() throws Exception{
        SystemTest st = new SystemTest(true,
                                       true,
                                       false,
                                       10,
                                       10,
                                       1,
                                       10,
                                       "testPersistentNonDurableTopicMessageB()");
        st.doTest();
    }

    /**
     * Unit test for persistent non-durable topic messages with the following settings:
     * 10 Producers, 10 Consumers, 10 Subjects, 10 Messages
     *
     * @throws Exception
     */
    public void testPersistentNonDurableTopicMessageC() throws Exception{
        SystemTest st = new SystemTest(true,
                                       true,
                                       false,
                                       10,
                                       10,
                                       10,
                                       10,
                                       "testPersistentNonDurableTopicMessageC()");
        st.doTest();
    }
}