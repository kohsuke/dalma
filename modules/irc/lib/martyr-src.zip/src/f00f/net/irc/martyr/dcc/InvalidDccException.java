package f00f.net.irc.martyr.dcc;

public class InvalidDccException extends DccException
{
	public InvalidDccException( String msg )
	{
		super(msg);
	}
}


