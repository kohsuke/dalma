/*
 * Copyright 1999-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.javaflow.bytecode.transformation.asm;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import org.apache.commons.io.IOUtils;
import org.apache.commons.javaflow.bytecode.transformation.ClassTransformer;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.objectweb.asm.ClassAdapter;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassVisitor;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodAdapter;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.analysis.Analyzer;
import org.objectweb.asm.tree.analysis.DataflowInterpreter;
import org.objectweb.asm.tree.analysis.Frame;
import org.objectweb.asm.util.TraceClassVisitor;

/**
 * @author tcurdt
 */
public final class AsmClassTransformer implements ClassTransformer {

    private final static Log log = LogFactory.getLog(AsmClassTransformer.class);

    class MyClassAdapter extends ClassAdapter {

        private String className;

        public MyClassAdapter(ClassVisitor cv) {
            super(cv);
        }


        public void visit( int version, int access, String name, String signature, String superName, String[] interfaces ) {
            cv.visit(version, access, name, signature, superName, interfaces);
            className = name;
        }


        public MethodVisitor visitMethod( int access, String name, String desc, String signature, String[] exceptions ) {
            // return a MethodNode so that the visited method will be stored as
            // a tree
            // (instead of being transformed on the fly and passed directly to
            // the next visitor in the chain)
 
            if (inScope(className, name) && "main".equals(name)) {
            return new MethodNode(access, name, desc, signature, exceptions) {

                private Collection labels = new ArrayList();
                
                public void visitMethodInsn( int opcode, String owner, String name, String desc ) {

                    if (needsFrameGuard(opcode, owner, name, desc) && inScope(owner, name)) {
                        System.out.println("creating label for " + owner + "." + name);

                        final Label label = new Label();
                        super.visitLabel(label);
                        labels.add(label);
                    }

                    super.visitMethodInsn(opcode, owner, name, desc);
                }

                public void visitEnd() {
                    // once the MethodNode is complete, compute the frames
                    final Frame[] frames;
                    if (instructions.size() > 0) {
                        Analyzer a = new Analyzer(new DataflowInterpreter());
                        //Analyzer a = new Analyzer(new BasicVerifier());
                        try {
                            a.analyze(className, this);
                        } catch (Exception ignored) {
                        }
                        frames = a.getFrames();
                    } else {
                        frames = new Frame[0];
                    }
                    System.out.println(labels.size() + " labels for method " + name);
                    System.out.println(frames.length + " frame states for method " + name);
                    // now make the next visitor in the chain (i.e. cv) visit
                    // this method
                    accept(new ClassAdapter(cv) {

                        public MethodVisitor visitMethod( int access, String name, String desc, String signature, String[] exceptions ) {
                            // insert an adapter to transform the method based
                            // on the computed frames
                            
                            final Label[] la = new Label[labels.size()];
                            labels.toArray(la);
                            
                            return new MyMethodAdapter(
                                    cv.visitMethod(access, name, desc, signature, exceptions),
                                    frames,
                                    la,
                                    name
                                    );
                        }
                    });
                }
            };
            } else {
                return super.visitMethod(access, name, desc, signature, exceptions);
            }
       }
    }

    class MyMethodAdapter extends MethodAdapter {

        private final Frame[] frames;
        private final Label[] labels;
        private final String name;
        private int currentInsn; // position in the *original* code


        public MyMethodAdapter(MethodVisitor mv, Frame[] frames, Label[] labels, String name) {
            super(mv);
            this.frames = frames;
            this.name = name;
            this.labels = labels;
        }

        public void visitCode() {
            mv.visitCode();

            mv.visitFieldInsn(Opcodes.GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
            mv.visitLdcInsn("entering " + name);
            mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V");

            //mv.visitTableSwitchInsn(0, labels.length-1 , null, labels);
            //mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "", "", "");
        }

        public void visitInsn( int opcode ) {

            if (opcode == Opcodes.RETURN) {
                mv.visitFieldInsn(Opcodes.GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
                mv.visitLdcInsn("returning from " + name);
                mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V");
            }
            
            mv.visitInsn(opcode);
            ++currentInsn;
        }


        public void visitMethodInsn( int opcode, String owner, String name, String desc ) {
            if (needsFrameGuard(opcode, owner, name, desc) && inScope(owner, name)) {

                mv.visitFieldInsn(Opcodes.GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
                mv.visitLdcInsn("before " + name);
                mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V");

                mv.visitMethodInsn(opcode, owner, name, desc);

                mv.visitFieldInsn(Opcodes.GETSTATIC, "java/lang/System", "out", "Ljava/io/PrintStream;");
                mv.visitLdcInsn("after " + name);
                mv.visitMethodInsn(Opcodes.INVOKEVIRTUAL, "java/io/PrintStream", "println", "(Ljava/lang/String;)V");
                
            } else {
                mv.visitMethodInsn(opcode, owner, name, desc);
            }
            // insert your code here if necessary,
            // you can use frames[currentInsn] to know frame types at this
            // point
            ++currentInsn;
        }
    }

    private boolean inScope(String owner, String name) {
        if (owner.startsWith("org/apache/commons/javaflow")) {
            return true;
        }
        
        return false;        
    }
    private boolean needsFrameGuard( int opcode, String owner, String name, String desc ) {
        if (opcode == Opcodes.INVOKEINTERFACE ||
            opcode == Opcodes.INVOKESPECIAL ||
            opcode == Opcodes.INVOKESTATIC ||
            opcode == Opcodes.INVOKEVIRTUAL ) {
            return true;
        }
        return false;
    }
    
    public byte[] transform( final byte[] original ) {
        // new ClassReader(original).accept(new TraceClassVisitor(new
        // ClassWriter(false), new PrintWriter(System.out)), false);
        final ClassReader cr = new ClassReader(original);
        final ClassWriter cw = new ClassWriter(true, false);
        final ClassVisitor cv = new MyClassAdapter(cw);
        cr.accept(cv, false);
        final byte[] transformed = cw.toByteArray();
        
        return transformed;
    }


    public static void main( String[] args ) throws Exception {
        final byte[] original = IOUtils.toByteArray(ClassLoader.getSystemResourceAsStream("org/apache/commons/javaflow/testcode/Test.class"));
        
        System.out.println("original=" + original.length);
        final byte[] transformed = new AsmClassTransformer().transform(original);
        System.out.println("transformed=" + transformed.length);
        
        /*
        System.out.println("running the original");
        Class originalClass = new BytecodeClassLoader().loadClass(original);
        Runnable orignalRunnable = (Runnable) originalClass.newInstance();
        try {
            orignalRunnable.run();
        } catch(IllegalStateException e) {
        }
        System.out.println("original finished");
        */

        new ClassReader(transformed).accept(new TraceClassVisitor(new ClassWriter(false), new PrintWriter(System.out)), false);

        /*
        System.out.println("running the transformed");
        Class transformedClass = new BytecodeClassLoader().loadClass(transformed);
        Runnable transformedRunnable = (Runnable) transformedClass.newInstance();
        transformedRunnable.run();
        System.out.println("transformed finished");
        */
    }
}