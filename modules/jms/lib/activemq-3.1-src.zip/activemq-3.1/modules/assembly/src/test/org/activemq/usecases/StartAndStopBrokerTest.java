/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.usecases;

import junit.framework.TestCase;
import org.activemq.ActiveMQConnectionFactory;
import org.activemq.broker.impl.BrokerConnectorImpl;
import org.activemq.broker.impl.BrokerContainerImpl;
import org.activemq.io.impl.DefaultWireFormat;

import javax.jms.JMSException;

/**
 * @author Oliver Belikan
 * @version $Revision: 1.1.1.1 $
 */
public class StartAndStopBrokerTest extends TestCase {
    public void testStartupShutdown() throws Exception {
        // This systemproperty is used if we dont want to
        // have persistence messages as a default
        System.setProperty("activemq.persistenceAdapter",
                "org.activemq.store.vm.VMPersistenceAdapter");

        // configuration of container and all protocolls
        BrokerContainerImpl container = createBroker();

        // start a client
        ActiveMQConnectionFactory factory = new
                ActiveMQConnectionFactory("tcp://localhost:9100");
        factory.start();
        factory.createConnection();

        // stop activemq broker
        container.stop();

        // start activemq broker again
        container = createBroker();

        // start a client again
        factory = new
                ActiveMQConnectionFactory("tcp://localhost:9100");
        factory.start();
        factory.createConnection();

        // stop activemq broker
        container.stop();

    }

    protected BrokerContainerImpl createBroker() throws JMSException {
        BrokerContainerImpl container = new BrokerContainerImpl("DefaultBroker");

        // Start internal vm protocoll
        BrokerConnectorImpl vmConnector = new BrokerConnectorImpl(container, "vm://localhost", new DefaultWireFormat());
        BrokerConnectorImpl tcpConnector = new BrokerConnectorImpl(container, "tcp://localhost:9100", new DefaultWireFormat());

        // start activemq broker
        container.start();
        return container;
    }

}
