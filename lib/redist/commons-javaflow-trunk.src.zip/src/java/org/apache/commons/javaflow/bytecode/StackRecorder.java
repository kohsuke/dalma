/*
 * Copyright 1999-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.javaflow.bytecode;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Adds additional behaviors necessary for stack capture/restore
 * on top of {@link Stack}.
 *
 * @author Kohsuke Kawaguchi
 */
public final class StackRecorder extends Stack {
    private final static Log log = LogFactory.getLog(StackRecorder.class);
    private static final long serialVersionUID = 1L;

    private transient boolean restoring = false;
    private transient boolean capturing = false;

    /**
     * Context object given by the user.
     */
    private transient Object context;

    private final static ThreadLocal threadMap = new ThreadLocal();

    /**
     * Creates a new empty {@link StackRecorder} that runs the given target.
     */
    public StackRecorder(Runnable target) {
        pushReference(target);
    }

    /**
     * Creates a clone of the given {@link StackRecorder}.
     */
    public StackRecorder(final Stack parent) {
        super(parent);
    }

    public static void suspend() {
        log.debug("suspend()");

        StackRecorder r = get();
        if(r==null) {
            throw new IllegalStateException("No continuation is running");
        }

        r.capturing = !r.restoring;
        r.restoring = false;
    }

    /**
     * True, if the continuation restores the previous stack trace to the last
     * invocation of suspend().
     */
    public boolean isRestoring() {
        return restoring;
    }

    /**
     * True, is the continuation freeze the strack trace, and stops the
     * continuation.
     */
    public boolean isCapturing() {
        return capturing;
    }

    public StackRecorder execute(final Object context) {
        final StackRecorder old = registerThread();
        Runnable target = (Runnable)popReference();
        try {
            restoring = !isEmpty(); // start restoring if we have a filled stack
            this.context = context;
            target.run();
            if (!capturing) {
                return null;
            }
        } finally {
            this.context = null;
            deregisterThread(old);
        }
        return this;
    }

    public Object getContext() {
        return context;
    }

    /**
     * Bind this stack recorder to running thread.
     */
    private StackRecorder registerThread() {
        StackRecorder old = get();
        threadMap.set(this);
        return old;
    }

    /**
     * Unbind the current stack recorder to running thread.
     */
    private void deregisterThread(final StackRecorder old) {
        threadMap.set(old);
    }

    /**
     * Return the continuation, which is associated to the current thread.
     */
    public static StackRecorder get() {
        return (StackRecorder)threadMap.get();
    }
}
