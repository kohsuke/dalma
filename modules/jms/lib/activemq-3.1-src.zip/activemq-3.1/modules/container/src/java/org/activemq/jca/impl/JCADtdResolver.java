/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.jca.impl;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;

import java.io.IOException;

/**
 * EntityResolver implementation for the MDO DTD,
 * to load the DTD from the MDO classpath JAR file.
 * <p/>
 * <p>Fetches "mdo.dtd" from the classpath resource
 * "/org/activemq/mdo/mdo.dtd",
 * no matter if specified as some local URL or as
 * "http://activemq.org/dtd/mdo.dtd".
 *
 * @version $Revision: 1.2 $
 */
public class JCADtdResolver implements EntityResolver {

    private static final String DTD_NAME = "mdo.dtd";

    private static final String SEARCH_PACKAGE = "/org/activemq/mdo/";

    protected final Log logger = LogFactory.getLog(getClass());

    public InputSource resolveEntity(String publicId, String systemId) throws IOException {
        logger.debug("Trying to resolve XML entity with public ID [" + publicId +
                "] and system ID [" + systemId + "]");
        if (systemId != null && systemId.indexOf(DTD_NAME) > systemId.lastIndexOf("/")) {

            String dtdFile = systemId.substring(systemId.indexOf(DTD_NAME));
            logger.debug("Trying to locate [" + dtdFile + "] under [" + SEARCH_PACKAGE + "]");
            try {
                String name = SEARCH_PACKAGE + dtdFile;
                Resource resource = new ClassPathResource(name, getClass());
                InputSource source = new InputSource(resource.getInputStream());
                source.setPublicId(publicId);
                source.setSystemId(systemId);
                logger.debug("Found beans DTD [" + systemId + "] in classpath");
                return source;
            }
            catch (IOException ex) {
                logger.debug("Could not resolve beans DTD [" + systemId + "]: not found in classpath", ex);
            }
        }
        // use the default behaviour -> download from website or wherever
        return null;
    }

}
