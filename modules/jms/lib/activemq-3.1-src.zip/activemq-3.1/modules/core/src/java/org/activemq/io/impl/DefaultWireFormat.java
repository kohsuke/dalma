/**
 *
 * Copyright 2004 Protique Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **/

package org.activemq.io.impl;
import java.io.DataInput;
import java.io.DataInputStream;
import java.io.DataOutput;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.activemq.io.WireFormat;
import org.activemq.io.util.WireByteArrayInputStream;
import org.activemq.io.util.WireByteArrayOutputStream;
import org.activemq.message.CachedValue;
import org.activemq.message.Packet;

/**
 * This is a stateful AbstractDefaultWireFormat which implements value caching.  Not optimal for use by 
 * many concurrent threads.  One DefaultWireFormat is typically allocated per client connection.  
 *  
 * @version $Revision: 1.1.1.1 $
 */
public class DefaultWireFormat extends AbstractDefaultWireFormat implements Serializable {

    private static final long serialVersionUID = -1454851936411678612L;

    private static final int MAX_CACHE_SIZE = Short.MAX_VALUE/2; //needs to be a lot less than Short.MAX_VALUE
    
    static final short NULL_VALUE = -1;
    static final short CLEAR_CACHE = -2;
    
    //
    // Fields used during a write.
    //
    protected transient final Object writeMutex = new Object();
    protected transient WireByteArrayOutputStream internalBytesOut;
    protected transient DataOutputStream internalDataOut;
    protected transient WireByteArrayOutputStream cachedBytesOut;
    protected transient DataOutputStream cachedDataOut;
    private Map writeValueCache = new HashMap();
    protected transient short cachedKeyGenerator;
    protected transient short lastWriteValueCacheEvictionPosition=500;
    
    //
    // Fields used during a read.
    //
    protected transient final Object readMutex = new Object();
    protected transient WireByteArrayInputStream internalBytesIn;
    protected transient DataInputStream internalDataIn;    
    private Object[] writeValueCacheArray = new Object[MAX_CACHE_SIZE];
    private Object[] readValueCacheArray = new Object[MAX_CACHE_SIZE];

    
    /**
     * Default Constructor
     */
    public DefaultWireFormat() {
        internalBytesOut = new WireByteArrayOutputStream();
        internalDataOut = new DataOutputStream(internalBytesOut);
        internalBytesIn = new WireByteArrayInputStream();
        internalDataIn = new DataInputStream(internalBytesIn);
        this.currentWireFormatVersion = WIRE_FORMAT_VERSION;
        this.cachedBytesOut = new WireByteArrayOutputStream();
        this.cachedDataOut = new DataOutputStream(cachedBytesOut);
    }    

    /**
     * @return new WireFormat
     */
    public WireFormat copy() {
        DefaultWireFormat format = new DefaultWireFormat();
        format.setCachingEnabled(cachingEnabled);
        format.setCurrentWireFormatVersion(getCurrentWireFormatVersion());
        return format;
    }
    
    
    private Object readResolve() throws ObjectStreamException {
        return new DefaultWireFormat();
    }
    
    public Packet writePacket(Packet packet, DataOutput dataOut) throws IOException {
        PacketWriter writer = getWriter(packet);
        if (writer != null) {
            synchronized (writeMutex) {
                internalBytesOut.reset();
                writer.writePacket(packet, internalDataOut);
                internalDataOut.flush();
                //reuse the byte buffer in the ByteArrayOutputStream
                byte[] data = internalBytesOut.getData();
                int count = internalBytesOut.size();
                dataOut.writeByte(packet.getPacketType());
                dataOut.writeInt(count);
                //byte[] data = internalBytesOut.toByteArray();
                //int count = data.length;
                //dataOut.writeInt(count);
                packet.setMemoryUsage(count);
                dataOut.write(data, 0, count);                
            }
        }
        return null;
    }

    protected synchronized final Packet readPacket(DataInput dataIn, PacketReader reader) throws IOException {
        synchronized (readMutex) {
            Packet packet = reader.createPacket();
            int length = dataIn.readInt();
            packet.setMemoryUsage(length);
            byte[] data = new byte[length];
            dataIn.readFully(data);
            //then splat into the internal datainput
            internalBytesIn.restart(data);
            reader.buildPacket(packet, internalDataIn);
            return packet;
        }
    }
    
    /**
     * A helper method which converts a packet into a byte array Overrides the WireFormat to make use of the internal
     * BytesOutputStream
     * 
     * @param packet
     * @return a byte array representing the packet using some wire protocol
     * @throws IOException
     */
    public byte[] toBytes(Packet packet) throws IOException {
        byte[] data = null;
        PacketWriter writer = getWriter(packet);

        if (writer != null) {
            
            synchronized (writeMutex) {
                internalBytesOut.reset();
                internalDataOut.writeByte(packet.getPacketType());
                internalDataOut.writeInt(-1);//the length
                writer.writePacket(packet, internalDataOut);
                internalDataOut.flush();
                data = internalBytesOut.toByteArray();
            }
            
            // lets subtract the header offset from the length
            int length = data.length - 5;
            packet.setMemoryUsage(length);
            //write in the length to the data
            data[1] = (byte) ((length >>> 24) & 0xFF);
            data[2] = (byte) ((length >>> 16) & 0xFF);
            data[3] = (byte) ((length >>> 8) & 0xFF);
            data[4] = (byte) ((length >>> 0) & 0xFF);
        }
        
        return data;
    }

    ///////////////////////////////////////////////////////////////
    //
    // Methods to handle cached values
    //
    ///////////////////////////////////////////////////////////////    
    
    public Object getValueFromReadCache(short key) {
        if( key < 0 || key > readValueCacheArray.length )
            return null;
        return readValueCacheArray[key];
    }
    
    protected short getWriteCachedKey(Object key) throws IOException{
        if (key != null){
            Short result = null;
            result = (Short)writeValueCache.get(key);
            if (result == null){
                result = getNextCacheId();
                writeValueCache.put(key,result);
                writeValueCacheArray[result.shortValue()]=key;
                updateCachedValue(result.shortValue(),key);                
            }
            return result.shortValue();
        }
        return DefaultWireFormat.NULL_VALUE;
    }

    /**
     * @return
     */
    private Short getNextCacheId() {
        Short result;
        result = new Short(cachedKeyGenerator++);
        // once we fill the cache start reusing old cache locations to avoid memory leaks.
        if (cachedKeyGenerator >= MAX_CACHE_SIZE) {
            cachedKeyGenerator=0;
        }
        
        lastWriteValueCacheEvictionPosition++;
        if (lastWriteValueCacheEvictionPosition >= MAX_CACHE_SIZE) {
            lastWriteValueCacheEvictionPosition=0;
        }
        
        if( writeValueCacheArray[lastWriteValueCacheEvictionPosition] !=null ) {
            Object o = writeValueCacheArray[lastWriteValueCacheEvictionPosition];
            writeValueCache.remove(o);
            writeValueCacheArray[lastWriteValueCacheEvictionPosition]=null;            
        }
        return result;
    }
    
    protected void validateWriteCache() throws IOException {
        if (cachingEnabled) {
            if (writeValueCache.size() >= MAX_CACHE_SIZE) {
                writeValueCache.clear();
                Arrays.fill(writeValueCacheArray,null);
                cachedKeyGenerator = 0;
                updateCachedValue((short) -1, null);// send update to peer to
                                                    // clear the peer cache
            }
        }
    }
    
    protected void handleCachedValue(CachedValue cv) {
        if (cv != null) {
            if (cv.getId() == CLEAR_CACHE) {
                Arrays.fill(readValueCacheArray, null);
            } else if (cv.getId() != NULL_VALUE) {
                readValueCacheArray[cv.getId()] = cv.getValue();
            }
        }
    }    
    
    private synchronized void updateCachedValue(short key, Object value) throws IOException {
        if (cachedValueWriter == null) {
            cachedValueWriter = new CachedValueWriter();
        }
        CachedValue cv = new CachedValue();
        cv.setId(key);
        cv.setValue(value);
        cachedBytesOut.reset();
        cachedValueWriter.writePacket(cv, cachedDataOut);
        cachedDataOut.flush();
        byte[] data = cachedBytesOut.getData();
        int count = cachedBytesOut.size();
        getTransportDataOut().writeByte(cv.getPacketType());
        getTransportDataOut().writeInt(count);
        getTransportDataOut().write(data, 0, count);
    }
}