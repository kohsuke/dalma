package org.activemq.usecases;

public class NonPersistentNonDurableTopicSystemTest extends SystemTest {

    /**
     * Sets up the resources of the unit test.
     *
     * @throws Exception
     */
    protected void setUp() throws Exception {
        System.out.println("############################################################");
        System.out.println("NonPersistentNonDurableTopicSystemTest.setUp()...");
        super.setUp();
    }

    /**
     * Clears up the resources used in the unit test.
     */
    protected void tearDown() throws Exception {
        System.out.println("NonPersistentNonDurableTopicSystemTest.tearDown()...");
        System.out.println("############################################################");
        super.tearDown();
    }

    /**
     * Unit test for non-persistent non-durable topic messages with the following settings:
     * 1 Producer, 1 Consumer, 1 Subject, 10 Messages
     *
     * @throws Exception
     */
    public void testNonPersistentNonDurableTopicMessageA() throws Exception{
        SystemTest st = new SystemTest(true,
                                       false,
                                       false,
                                       1,
                                       1,
                                       1,
                                       10,
                                       "testNonPersistentNonDurableTopicMessageA()");
        st.doTest();
    }

    /**
     * Unit test for non-persistent non-durable topic messages with the following settings:
     * 10 Producers, 10 Consumers, 1 Subject, 10 Messages
     *
     * @throws Exception
     */
    public void testNonPersistentNonDurableTopicMessageB() throws Exception{
        SystemTest st = new SystemTest(true,
                                       false,
                                       false,
                                       10,
                                       10,
                                       1,
                                       10,
                                       "testNonPersistentNonDurableTopicMessageB()");
        st.doTest();
    }

    /**
     * Unit test for non-persistent non-durable topic messages with the following settings:
     * 10 Producers, 10 Consumers, 10 Subjects, 10 Messages
     *
     * @throws Exception
     */
    public void testNonPersistentNonDurableTopicMessageC() throws Exception{
        SystemTest st = new SystemTest(true,
                                       false,
                                       false,
                                       10,
                                       10,
                                       10,
                                       10,
                                       "testNonPersistentNonDurableTopicMessageC()");
        st.doTest();
    }
}