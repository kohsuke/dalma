/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.jca;

import java.io.InputStream;

import org.activemq.jca.impl.JCABeanDefinitionReader;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.core.io.InputStreamResource;
import org.springframework.core.io.Resource;

/**
 * A Spring BeanFactory for creating an JCA container
 *
 * @version $Revision: 1.1.1.1 $
 */
public class JCABeanFactory extends DefaultListableBeanFactory {

    private XmlBeanDefinitionReader reader;

    /**
     * Create a new JCABeanFactory with the given resource,
     * which must be parsable using DOM.
     *
     * @param resource XML resource to load bean definitions from
     * @throws org.springframework.beans.BeansException
     *          in case of loading or parsing errors
     */
    public JCABeanFactory(Resource resource) throws BeansException {
        this(resource, null);
    }

    /**
     * Create a new JCABeanFactory with the given InputStream,
     * which must be parsable using DOM.
     * <p>It's preferable to use a Resource argument instead of an
     * InputStream, to retain location information. This constructor
     * is mainly kept for backward compatibility.
     *
     * @param is XML InputStream to load bean definitions from
     * @throws org.springframework.beans.BeansException
     *          in case of loading or parsing errors
     * @see #JCABeanFactory(org.springframework.core.io.Resource)
     */
    public JCABeanFactory(InputStream is) throws BeansException {
        this(new InputStreamResource(is, "(no description)"), null);
    }

    /**
     * Create a new JCABeanFactory with the given input stream,
     * which must be parsable using DOM.
     *
     * @param resource          XML resource to load bean definitions from
     * @param parentBeanFactory parent bean factory
     * @throws org.springframework.beans.BeansException
     *          in case of loading or parsing errors
     */
    public JCABeanFactory(Resource resource, BeanFactory parentBeanFactory) throws BeansException {
        super(parentBeanFactory);
        getReader().loadBeanDefinitions(resource);
    }

    /**
     * Lazily creates a reader on demand
     *
     * @return
     */
    protected XmlBeanDefinitionReader getReader() {
        if (reader == null) {
            reader = createReader();
        }
        return reader;
    }

    /**
     * A hook to allow custom ActiveMQBeanFactory implementations to provide
     * their own custom parser of the XML to perform macro processing
     * or perform XSLT etc
     *
     * @return
     */
    protected XmlBeanDefinitionReader createReader() {
        return new JCABeanDefinitionReader(this);
    }
}
