package org.apache.commons.javaflow.bytecode;

/**
 * This exception is used to signal that the continuation
 * wants to exit the execution.
 *
 * @author Kohsuke Kawaguchi
 */
public class ContinuationDeath extends Error {}
