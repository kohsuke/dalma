package f00f.net.irc.martyr.dcc;

public class DccException extends Exception
{
	public DccException( String msg )
	{
		super(msg);
	}
}


