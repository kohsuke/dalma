/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/


package org.activemq.capacity;


/**
 * A CapacityMonitorEvent is raised to notify that a change has occurred to the 
 * capacity of  a CapacityMonitor
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class CapacityMonitorEvent {
    private String monitorName;
    private int capacity;

    /**
     * Default Constructor
     *
     */
    public CapacityMonitorEvent() {
    }
    
    /**
     * 
     * @param name
     * @param newCapacity
     */
    
    public CapacityMonitorEvent(String name,int newCapacity){
        this.monitorName = name;
        this.capacity = newCapacity;
    }

   
    /**
     * @return Returns the capacity.
     */
    public int getCapacity() {
        return capacity;
    }
    /**
     * @param capacity The capacity to set.
     */
    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }
    /**
     * @return Returns the monitorName.
     */
    public String getMonitorName() {
        return monitorName;
    }
    /**
     * @param monitorName The monitorName to set.
     */
    public void setMonitorName(String monitorName) {
        this.monitorName = monitorName;
    }
    
    /**
     * @return a pretty print of this 
     */
    public String toString(){
        return monitorName + ": capacity = " + capacity;
    }
}
