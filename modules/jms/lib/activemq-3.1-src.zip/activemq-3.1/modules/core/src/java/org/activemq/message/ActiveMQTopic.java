/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.message;

import javax.jms.Destination;
import javax.jms.Topic;

import org.activemq.management.JMSDestinationStats;
import org.activemq.management.JMSTopicStatsImpl;


/**
 * A <CODE>Topic</CODE> object encapsulates a provider-specific topic name.
 * It is the way a client specifies the identity of a topic to JMS API methods.
 * For those methods that use a <CODE>Destination</CODE> as a parameter, a
 * <CODE>Topic</CODE> object may used as an argument . For
 * example, a Topic can be used to create a <CODE>MessageConsumer</CODE>
 * and a <CODE>MessageProducer</CODE>
 * by calling:
 * <UL>
 * <LI> <CODE>Session.CreateConsumer(Destination destination)</CODE>
 * <LI> <CODE>Session.CreateProducer(Destination destination)</CODE>
 * <p/>
 * </UL>
 * <p/>
 * <P>Many publish/subscribe (pub/sub) providers group topics into hierarchies
 * and provide various options for subscribing to parts of the hierarchy. The
 * JMS API places no restriction on what a <CODE>Topic</CODE> object
 * represents. It may be a leaf in a topic hierarchy, or it may be a larger
 * part of the hierarchy.
 * <p/>
 * <P>The organization of topics and the granularity of subscriptions to
 * them is an important part of a pub/sub application's architecture. The JMS
 * API
 * does not specify a policy for how this should be done. If an application
 * takes advantage of a provider-specific topic-grouping mechanism, it
 * should document this. If the application is installed using a different
 * provider, it is the job of the administrator to construct an equivalent
 * topic architecture and create equivalent <CODE>Topic</CODE> objects.
 *
 * @see javax.jms.Session#createConsumer(javax.jms.Destination)
 * @see javax.jms.Session#createProducer(javax.jms.Destination)
 * @see javax.jms.TopicSession#createTopic(String)
 */

public class ActiveMQTopic extends ActiveMQDestination implements Topic {

    private static final long serialVersionUID = -4243052759456351987L;

    /**
     * Default constructor for an ActiveMQTopic Destination
     */
    public ActiveMQTopic() {
        super();
    }

    /**
     * Construct a named ActiveMQTopic Destination
     *
     * @param name
     */

    public ActiveMQTopic(String name) {
        super(name);
    }

    /**
     * Gets the name of this Topic.
     * <p/>
     * <P>Clients that depend upon the name are not portable.
     *
     * @return the Topic name
     */

    public String getTopicName() {
        return super.getPhysicalName();
    }

    /**
     * @return Returns the Destination type
     */

    public int getDestinationType() {
        return ACTIVEMQ_TOPIC;
    }

    protected Destination createDestination(String name) {
        return new ActiveMQTopic(name);
    }

    protected JMSDestinationStats createDestinationStats() {
        return new JMSTopicStatsImpl();
    }

}
