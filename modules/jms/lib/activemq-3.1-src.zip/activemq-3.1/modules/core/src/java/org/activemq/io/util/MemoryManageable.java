
package org.activemq.io.util;




public interface MemoryManageable {

    /**
     * Get an id that can be used to identify the object.
     * 
     * @return an object that can be used as an Id for this object.
     */
    public abstract Object getMemoryId();
    
    /**
     * Get a hint about how much memory this Packet is consuming
     *
     * @return an aproximation of the current memory used by this instance
     */
    public abstract int getMemoryUsage();

    /**
     * Increment reference count for bounded memory collections
     *
     * @return the incremented reference value
     * @see org.activemq.io.util.MemoryBoundedQueue
     */
    public abstract int incrementMemoryReferenceCount();

    /**
     * Decrement reference count for bounded memory collections
     *
     * @return the decremented reference value
     * @see org.activemq.io.util.MemoryBoundedQueue
     */
    public abstract int decrementMemoryReferenceCount();

    /**
     * @return the current reference count for bounded memory collections
     * @see org.activemq.io.util.MemoryBoundedQueue
     */
    public abstract int getMemoryUsageReferenceCount();
    
    public abstract int getPriority();

}