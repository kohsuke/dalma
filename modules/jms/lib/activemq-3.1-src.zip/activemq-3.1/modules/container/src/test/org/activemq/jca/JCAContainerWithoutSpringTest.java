package org.activemq.jca;

import javax.jms.Connection;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.Session;

import junit.framework.TestCase;

import org.activemq.ActiveMQConnectionFactory;
import org.activemq.ra.ActiveMQActivationSpec;
import org.activemq.ra.ActiveMQResourceAdapter;
import org.activemq.work.SpringWorkManager;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;

import EDU.oswego.cs.dl.util.concurrent.Slot;

public class JCAContainerWithoutSpringTest extends TestCase {
    
    public void testSendReceiveWithVMConnection() throws Exception {
        
        final Slot messageSlot = new Slot();
        
        final MessageListener bean = new MessageListener() {
            public void onMessage(Message message) {
                System.out.println(message);
                try {
                    messageSlot.offer(message, 1000);
                } catch (InterruptedException e) {
                }
            }            
        };

        JCAContainer jcac = new JCAContainer();
        jcac.setBeanFactory(new BeanFactory() {
            public Object getBean(String name) throws BeansException {
                return bean;
            }
            public Object getBean(String name, Class clazz) throws BeansException {
                return bean;
            }
            public boolean containsBean(String name) {
                return true;
            }
            public boolean isSingleton(String name) throws NoSuchBeanDefinitionException {
                return true;
            }
            public String[] getAliases(String name) throws NoSuchBeanDefinitionException {
                return null;
            }
            public Class getType(String arg0) throws NoSuchBeanDefinitionException {
                return null;
            }
        });

        ActiveMQResourceAdapter ra = new ActiveMQResourceAdapter();
        ra.setServerUrl("vm://localhost");
        ra.setBrokerXmlConfig("org/activemq/jca/broker-vmpersistence.xml");
        ra.setUseEmbeddedBroker(Boolean.TRUE);

        jcac.setResourceAdapter(ra);

        SpringWorkManager wm = new SpringWorkManager();
        wm.afterPropertiesSet();

        jcac.setWorkManager(wm);

        jcac.afterPropertiesSet();

        ActiveMQActivationSpec spec = new ActiveMQActivationSpec();
        spec.setDestinationType(Queue.class.getName());
        spec.setDestination("GauntletWorkQueue");
        spec.validate();

        JCAConnector connector = jcac.addConnector();
        connector.setActivationSpec(spec);
        connector.setRef("test");
        connector.setBeanFactory(jcac.getBeanFactory());
        connector.afterPropertiesSet();
        
        // Fire a test message into the broker.
        ActiveMQConnectionFactory factory = new ActiveMQConnectionFactory("vm://localhost");
        Connection connection = factory.createConnection();
        Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
        Queue queue = session.createQueue("GauntletWorkQueue");
        MessageProducer producer = session.createProducer(queue);
        producer.send(session.createTextMessage("test"));
        System.out.println("Message sent");
        connection.close();
        
        // Assert the message got there:
        assertNotNull(messageSlot.poll(1000*5));        
        
    }

}
