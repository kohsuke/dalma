/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq;

import org.activemq.broker.BrokerContainer;

import javax.jms.Connection;
import javax.jms.JMSException;
import javax.jms.QueueConnection;
import javax.jms.TopicConnection;
import javax.jms.XAConnection;
import javax.jms.XAConnectionFactory;
import javax.jms.XAQueueConnection;
import javax.jms.XAQueueConnectionFactory;
import javax.jms.XATopicConnection;
import javax.jms.XATopicConnectionFactory;

/**
 * The XAConnectionFactory interface is a base interface for the
 * XAQueueConnectionFactory and XATopicConnectionFactory interfaces.
 * <p/>
 * Some application servers provide support for grouping JTS capable resource
 * use into a distributed transaction (optional). To include JMS API
 * transactions in a JTS transaction, an application server requires a JTS
 * aware JMS  provider. A JMS provider exposes its JTS support using an
 * XAConnectionFactory object, which an application server uses to create
 * XAConnection objects.
 * <p/>
 * XAConnectionFactory objects are JMS administered objects, just like
 * ConnectionFactory objects. It is expected that application servers will
 * find them using the Java Naming and Directory  Interface (JNDI) API.
 * <p/>
 * The XAConnectionFactory interface is optional. JMS providers are not
 * required to support this interface. This interface is for use by JMS
 * providers to support transactional environments. Client programs are
 * strongly encouraged to use the transactional support  available in their
 * environment, rather than use these XA  interfaces directly.
 *
 * @version $Revision: 1.1.1.1 $
 * @see javax.jms.ConnectionFactory
 */
public class ActiveMQXAConnectionFactory extends ActiveMQConnectionFactory implements XAConnectionFactory, XAQueueConnectionFactory, XATopicConnectionFactory {

    public ActiveMQXAConnectionFactory() {
        super();
    }

    public ActiveMQXAConnectionFactory(String brokerURL) {
        super(brokerURL);
    }

    public ActiveMQXAConnectionFactory(String userName, String password, String brokerURL) {
        super(userName, password, brokerURL);
    }

    public ActiveMQXAConnectionFactory(BrokerContainer container) {
        super(container);
    }

    public ActiveMQXAConnectionFactory(BrokerContainer container, String brokerURL) {
        super(container, brokerURL);
    }

    public XAConnection createXAConnection() throws JMSException {
        return createActiveMQXAConnection(this.userName, this.password);
    }

    public XAConnection createXAConnection(String userName, String password) throws JMSException {
        return createActiveMQXAConnection(userName, password);
    }

    public XAQueueConnection createXAQueueConnection() throws JMSException {
        return createActiveMQXAConnection(userName, password);
    }

    public XAQueueConnection createXAQueueConnection(String userName, String password) throws JMSException {
        return createActiveMQXAConnection(userName, password);
    }

    public XATopicConnection createXATopicConnection() throws JMSException {
        return createActiveMQXAConnection(userName, password);
    }

    public XATopicConnection createXATopicConnection(String userName, String password) throws JMSException {
        return createActiveMQXAConnection(userName, password);
    }

    public Connection createConnection() throws JMSException {
        return createActiveMQXAConnection(userName, password);
    }

    public Connection createConnection(String userName, String password) throws JMSException {
        return createActiveMQXAConnection(userName, password);
    }

    public QueueConnection createQueueConnection() throws JMSException {
        return createActiveMQXAConnection(userName, password);
    }

    public QueueConnection createQueueConnection(String userName, String password) throws JMSException {
        return createActiveMQXAConnection(userName, password);
    }

    public TopicConnection createTopicConnection() throws JMSException {
        return createActiveMQXAConnection(userName, password);
    }

    public TopicConnection createTopicConnection(String userName, String password) throws JMSException {
        return createActiveMQXAConnection(userName, password);
    }

    protected ActiveMQXAConnection createActiveMQXAConnection(String userName, String password) throws JMSException {
        ActiveMQXAConnection connection = new ActiveMQXAConnection(this, userName, password, createTransportChannel(this.brokerURL));
        connection.setUseAsyncSend(isUseAsyncSend());
        if (this.clientID != null && this.clientID.length() > 0) {
            connection.setClientID(this.clientID);
        }
        return connection;
    }

}
