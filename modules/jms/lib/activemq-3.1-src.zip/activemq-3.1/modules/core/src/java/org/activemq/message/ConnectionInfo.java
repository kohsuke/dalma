/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.message;

import java.io.Serializable;
import java.util.Properties;

/**
 * Describes a Connection
 *
 * @version $Revision: 1.1.1.1 $
 */

public class ConnectionInfo extends AbstractPacket implements Serializable{
    /**
     * Hint for transport(s) about message delivery
     */
    public static String NO_DELAY_PROPERTY = "noDelay";
    static final long serialVersionUID = 55678222l;
    String clientId;
    String userName;
    String password;
    String hostName;
    String clientVersion;
    int wireFormatVersion;
    long startTime;
    boolean started;
    boolean closed;
    Properties properties = new Properties();
    

    /**
     * Return the type of Packet
     *
     * @return integer representation of the type of Packet
     */

    public int getPacketType() {
        return ACTIVEMQ_CONNECTION_INFO;
    }

    /**
     * Test for equality
     *
     * @param obj object to test
     * @return true if equivalent
     */
    public boolean equals(Object obj) {
        boolean result = false;
        if (obj != null && obj instanceof ConnectionInfo) {
            ConnectionInfo info = (ConnectionInfo) obj;
            result = this.clientId.equals(info.clientId);
        }
        return result;
    }

    /**
     * @return hash code for instance
     */
    public int hashCode() {
        return this.clientId != null ? this.clientId.hashCode() : super.hashCode();
    }


    /**
     * @return Returns the clientId.
     */
    public String getClientId() {
        return this.clientId;
    }

    /**
     * @param newClientId The clientId to set.
     */
    public void setClientId(String newClientId) {
        this.clientId = newClientId;
    }

    /**
     * @return Returns the hostName.
     */
    public String getHostName() {
        return this.hostName;
    }

    /**
     * @param newHostName The hostName to set.
     */
    public void setHostName(String newHostName) {
        this.hostName = newHostName;
    }

    /**
     * @return Returns the password.
     */
    public String getPassword() {
        return this.password;
    }

    /**
     * @param newPassword The password to set.
     */
    public void setPassword(String newPassword) {
        this.password = newPassword;
    }

    /**
     * @return Returns the properties.
     */
    public Properties getProperties() {
        return this.properties;
    }

    /**
     * @param newProperties The properties to set.
     */
    public void setProperties(Properties newProperties) {
        this.properties = newProperties;
    }

    /**
     * @return Returns the startTime.
     */
    public long getStartTime() {
        return this.startTime;
    }

    /**
     * @param newStartTime The startTime to set.
     */
    public void setStartTime(long newStartTime) {
        this.startTime = newStartTime;
    }

    /**
     * @return Returns the userName.
     */
    public String getUserName() {
        return this.userName;
    }

    /**
     * @param newUserName The userName to set.
     */
    public void setUserName(String newUserName) {
        this.userName = newUserName;
    }

    /**
     * @return Returns the started.
     */
    public boolean isStarted() {
        return started;
    }

    /**
     * @param started The started to set.
     */
    public void setStarted(boolean started) {
        this.started = started;
    }

    /**
     * @return Returns the closed.
     */
    public boolean isClosed() {
        return closed;
    }

    /**
     * @param closed The closed to set.
     */
    public void setClosed(boolean closed) {
        this.closed = closed;
    }
    /**
     * @return Returns the clientVersion.
     */
    public String getClientVersion() {
        return clientVersion;
    }
    /**
     * @param clientVersion The clientVersion to set.
     */
    public void setClientVersion(String clientVersion) {
        this.clientVersion = clientVersion;
    }
    /**
     * @return Returns the wireFormatVersion.
     */
    public int getWireFormatVersion() {
        return wireFormatVersion;
    }
    /**
     * @param wireFormatVersion The wireFormatVersion to set.
     */
    public void setWireFormatVersion(int wireFormatVersion) {
        this.wireFormatVersion = wireFormatVersion;
    }


    public String toString() {
        return super.toString() + " ConnectionInfo{ " +
                "clientId = '" + clientId + "' " +
                ", userName = '" + userName + "' " +
                ", hostName = '" + hostName + "' " +
                ", clientVersion = '" + clientVersion + "' " +
                ", wireFormatVersion = " + wireFormatVersion +
                ", startTime = " + startTime +
                ", started = " + started +
                ", closed = " + closed +
                ", properties = " + properties +
                " }";
    }    
}
