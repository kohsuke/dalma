/*
 * Copyright 1999-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.javaflow.bytecode;

import org.apache.commons.javaflow.utils.ReflectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Adds additional behaviors necessary for stack capture/restore
 * on top of {@link Stack}.
 *
 * @author Kohsuke Kawaguchi
 */
public final class StackRecorder extends Stack {
    private final static Log log = LogFactory.getLog(StackRecorder.class);
    private static final long serialVersionUID = 1L;

    private transient boolean restoring = false;
    private transient boolean capturing = false;

    /**
     * Context object given by the user.
     */
    private transient Object context;

    private final static ThreadLocal threadMap = new ThreadLocal();

    /**
     * Creates a new empty {@link StackRecorder} that runs the given target.
     */
    public StackRecorder(Runnable target) {
        super(target);
    }

    /**
     * Creates a clone of the given {@link StackRecorder}.
     */
    public StackRecorder(final Stack parent) {
        super(parent);
    }

    public static void suspend() {
        log.debug("suspend()");

        StackRecorder r = get();
        if(r==null) {
            throw new IllegalStateException("No continuation is running");
        }

        r.capturing = !r.restoring;
        r.restoring = false;
    }

    /**
     * True, if the continuation restores the previous stack trace to the last
     * invocation of suspend().
     */
    public boolean isRestoring() {
        return restoring;
    }

    /**
     * True, is the continuation freeze the strack trace, and stops the
     * continuation.
     */
    public boolean isCapturing() {
        return capturing;
    }

    public StackRecorder execute(final Object context) {
        final StackRecorder old = registerThread();
        try {
            restoring = !isEmpty(); // start restoring if we have a filled stack
            this.context = context;
            
            if (restoring) {
                log.debug("Restoring state of " + ReflectionUtils.getClassName(runnable) + "/" + ReflectionUtils.getClassLoaderName(runnable));
            }
            
            log.debug("calling runnable");
            runnable.run();

            if (capturing) {
                // the top of the reference stack is always the same as 'runnable'.
                // since we won't use this (instead we use 'runnable') for restoring
                // the stack frame, we need to throw it away now, or else the restoration won't work.
                if(isEmpty() || popReference()!=runnable) {
                    // if we were really capturing the stack, at least we should have
                    // one object in the reference stack. Otherwise, it usually means
                    // that the application wasn't instrumented correctly.
                    throw new IllegalStateException("stack corruption. Is "+runnable.getClass()+" instrumented for javaflow?");
                }
                return this;
            } else {
                return null;    // nothing more to continue
            }
        } catch(Error e) {
            log.error(e.getMessage(),e);
            throw e;
        } catch(RuntimeException e) {
            log.error(e.getMessage(),e);
            throw e;
        } finally {
            this.context = null;
            deregisterThread(old);
        }
    }

    public Object getContext() {
        return context;
    }

    /**
     * Bind this stack recorder to running thread.
     */
    private StackRecorder registerThread() {
        StackRecorder old = get();
        threadMap.set(this);
        return old;
    }

    /**
     * Unbind the current stack recorder to running thread.
     */
    private void deregisterThread(final StackRecorder old) {
        threadMap.set(old);
    }

    /**
     * Return the continuation, which is associated to the current thread.
     */
    public static StackRecorder get() {
        return (StackRecorder)threadMap.get();
    }
}
