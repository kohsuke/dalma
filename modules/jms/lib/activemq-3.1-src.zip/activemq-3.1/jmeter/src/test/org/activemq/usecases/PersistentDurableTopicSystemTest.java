package org.activemq.usecases;

public class PersistentDurableTopicSystemTest extends SystemTest {

    /**
     * Sets up the resources of the unit test.
     *
     * @throws Exception
     */
    protected void setUp() throws Exception {
        System.out.println("############################################################");
        System.out.println("PersistentDurableTopicSystemTest.setUp()...");
        super.setUp();
    }

    /**
     * Clears up the resources used in the unit test.
     */
    protected void tearDown() throws Exception {
        System.out.println("PersistentDurableTopicSystemTest.tearDown()...");
        System.out.println("############################################################");
        super.tearDown();
    }

    /**
     * Unit test for persistent durable topic messages with the following settings:
     * 1 Producer, 1 Consumer, 1 Subject, 10 Messages
     *
     * @throws Exception
     */
    public void testPersistentDurableTopicMessageA() throws Exception {
        SystemTest st = new SystemTest(true,
                                       true,
                                       true,
                                       1,
                                       1,
                                       1,
                                       10,
                                       "testPersistentDurableTopicMessageA()");
        st.doTest();
    }

    /**
     * Unit test for persistent durable topic messages with the following settings:
     * 10 Producers, 10 Consumers, 1 Subject, 10 Messages
     *
     * @throws Exception
     */
    public void testPersistentDurableTopicMessageB() throws Exception{
        SystemTest st = new SystemTest(true,
                                       true,
                                       true,
                                       10,
                                       10,
                                       1,
                                       10,
                                       "testPersistentDurableTopicMessageB()");
        st.doTest();
    }

    /**
     * Unit test for persistent durable topic messages with the following settings:
     * 10 Producers, 10 Consumers, 10 Subjects, 10 Messages
     *
     * @throws Exception
     */
    public void testPersistentDurableTopicMessageC() throws Exception{
        SystemTest st = new SystemTest(true,
                                       true,
                                       true,
                                       10,
                                       10,
                                       10,
                                       10,
                                       "testPersistentDurableTopicMessageC()");
        st.doTest();
     }
}