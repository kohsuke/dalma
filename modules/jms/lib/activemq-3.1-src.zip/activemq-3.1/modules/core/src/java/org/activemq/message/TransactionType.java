/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.message;

/**
 * @version $Revision: 1.1.1.1 $
 */
public interface TransactionType {
    
    /**
     * Transaction state not set
     */
    int NOT_SET = 0;
    /**
     * Start a transaction
     */
    int START = 101;
    /**
     * Pre-commit a transaction
     */
    int PRE_COMMIT = 102;
    /**
     * Commit a transaction
     */
    int COMMIT = 103;
    /**
     * Recover a transaction
     */
    int RECOVER = 104;
    /**
     * Rollback a transaction
     */
    int ROLLBACK = 105;
    /**
     * End a transaction
     */
    int END = 106;
    /**
     * Forget a transaction
     */
    int FORGET = 107;
    /**
     * Join a transaction
     */
    int JOIN = 108;
    /**
     * Do a one phase commit...  No PRE COMMIT has been done.
     */
    int COMMIT_ONE_PHASE = 109;
    /**
     * Get a list of all the XIDs that are currently prepared.
     */
    int XA_RECOVER = 110;
    /**
     * Get a the transaction timeout for the RM
     */
    int GET_TX_TIMEOUT = 111;
    /**
     * Set a the transaction timeout for the RM
     */
    int SET_TX_TIMEOUT = 112;
    /**
     * Gets the unique id of the resource manager.
     */
    int GET_RM_ID = 113;
}
