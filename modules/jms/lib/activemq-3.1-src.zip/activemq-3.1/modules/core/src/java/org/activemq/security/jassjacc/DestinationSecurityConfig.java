/*
 * Created on Nov 7, 2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package org.activemq.security.jassjacc;

import java.util.HashSet;

import org.activemq.message.ActiveMQDestination;

/**
 * @author Hiram
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class DestinationSecurityConfig {
	
	String brokerName;
	ActiveMQDestination destination;
	
	HashSet consumeRoles = new HashSet();
	HashSet produceRoles = new HashSet();
	HashSet sendRoles = new HashSet();
	
	/**
	 * @return Returns the brokerName.
	 */
	public String getBrokerName() {
		return brokerName;
	}
	/**
	 * @param brokerName The brokerName to set.
	 */
	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}
	/**
	 * @return Returns the consumeRoles.
	 */
	public HashSet getConsumeRoles() {
		return consumeRoles;
	}
	/**
	 * @param consumeRoles The consumeRoles to set.
	 */
	public void setConsumeRoles(HashSet consumeRoles) {
		this.consumeRoles = consumeRoles;
	}
	/**
	 * @return Returns the destination.
	 */
	public ActiveMQDestination getDestination() {
		return destination;
	}
	/**
	 * @param destination The destination to set.
	 */
	public void setDestination(ActiveMQDestination destination) {
		this.destination = destination;
	}
	/**
	 * @return Returns the produceRoles.
	 */
	public HashSet getProduceRoles() {
		return produceRoles;
	}
	/**
	 * @param produceRoles The produceRoles to set.
	 */
	public void setProduceRoles(HashSet produceRoles) {
		this.produceRoles = produceRoles;
	}
	/**
	 * @return Returns the sendRoles.
	 */
	public HashSet getSendRoles() {
		return sendRoles;
	}
	/**
	 * @param sendRoles The sendRoles to set.
	 */
	public void setSendRoles(HashSet sendRoles) {
		this.sendRoles = sendRoles;
	}
}
