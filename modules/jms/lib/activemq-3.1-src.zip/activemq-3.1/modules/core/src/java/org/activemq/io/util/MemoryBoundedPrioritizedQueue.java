/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.io.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.jms.JMSException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.activemq.service.QueueListEntry;
import org.activemq.service.impl.DefaultQueueList;

/**
 * @author Ramzi Saba
 *
 * A prioritized version of the MemoryBoundedQueue supporting the 10 JMS priority levels
 * 0-9, 0 being the lowest and 9 being the highest.
 *
 * @version $Revision: 1.1.1.1 $
 */
public class MemoryBoundedPrioritizedQueue extends MemoryBoundedQueue {
    
    private static final Log log = LogFactory.getLog(MemoryBoundedPrioritizedQueue.class);    
    private static final int DEFAULT_PRIORITY = 4;
    private final DefaultQueueList[] prioritizedPackets = new DefaultQueueList[10]; // array of 10 prioritized queues

    /**
     * Constructor
     *
     * @param name
     * @param manager
     * @param name 
     */
    public MemoryBoundedPrioritizedQueue(MemoryBoundedQueueManager manager, String name) {
    	super(manager, name);
        for (int i=0; i<10; ++i) {
        	this.prioritizedPackets[i] = new DefaultQueueList();
        }
    }

    /**
     * @return the number of items held by this queue
     */
    public int size() {
        //return internalList.size();
    	int size=0;
    	for (int j=0; j<10; ++j) {
    		size += prioritizedPackets[j].size();
    	}
    	return size;
    }

    /**
     * Enqueue a MemoryManageable without checking memory usage limits
     *
     * @param packet
     */
    public void enqueueNoBlock(MemoryManageable packet) {
        if (!closed) {
            //internalList.add(packet);
        	prioritizedPackets[getPacketPriority(packet)].add(packet);
            incrementMemoryUsed(packet);
            synchronized (outLock) {
                outLock.notify();
            }
        }
    }

    /**
     * Enqueue a packet to the head of the queue with total disregard for memory constraints
     *
     * @param packet
     */
    public final void enqueueFirstNoBlock(MemoryManageable packet) {
        if (!closed) {
            //internalList.addFirst(packet);
        	prioritizedPackets[getPacketPriority(packet)].addFirst(packet);
            incrementMemoryUsed(packet);
            synchronized (outLock) {
                outLock.notify();
            }
        }
    }

    /**
     * Enqueue an array of packets to the head of the queue with total disregard for memory constraints
     *
     * @param packets
     */
    public void enqueueAllFirstNoBlock(List packets) {
        if (!closed) {
            //internalList.addAllFirst(packets);
            Iterator iterator = packets.iterator();
            for (Iterator iter = packets.iterator(); iter.hasNext();) {
                MemoryManageable packet = (MemoryManageable) iter.next();
                prioritizedPackets[getPacketPriority(packet)].addFirst(packet);
                incrementMemoryUsed(packet);
            }
            synchronized (outLock) {
                outLock.notify();
            }
        }
    }

    /**
     * @return the first dequeued MemoryManageable or blocks until one is available
     * @throws InterruptedException
     */
    public MemoryManageable dequeue() throws InterruptedException {
        MemoryManageable result = null;
        synchronized (outLock) {
            //while (internalList.isEmpty() && !closed) {
            while (isEmpty() && !closed) {
                outLock.wait(WAIT_TIMEOUT);
            }
            result = dequeueNoWait();
        }
        return result;
    }

    /**
     * dequeues a MemoryManageable from the head of the queue
     *
     * @return the MemoryManageable at the head of the queue or null, if none is available
     * @throws InterruptedException
     */
    public MemoryManageable dequeueNoWait() throws InterruptedException {
        MemoryManageable packet = null;
        synchronized (outLock) {
            while (stopped && !closed) {
                outLock.wait(WAIT_TIMEOUT);
            }
        }
        //packet = (MemoryManageable) internalList.removeFirst();
        for (int i=9; i>=0; --i) {
        	packet = (MemoryManageable) prioritizedPackets[i].removeFirst();
        	if (packet != null) break;
        }
        decrementMemoryUsed(packet);
        if (packet != null) {
            synchronized (inLock) {
                inLock.notify();
            }
        }
        return packet;
    }

    /**
     * Remove a packet from the queue
     *
     * @param packet
     * @return true if the packet was found
     */
    public boolean remove(MemoryManageable packet) {
        boolean result = false;
        //if (!internalList.isEmpty()) {
        if (!isEmpty()) {
            //result = internalList.remove(packet);
        	result = prioritizedPackets[getPacketPriority(packet)].remove(packet);
        }
        if (result) {
            decrementMemoryUsed(packet);
        }
        synchronized (inLock) {
            inLock.notify();
        }
        return result;
    }

    /**
     * Remove a MemoryManageable by it's id
     *
     * @param id
     * @return
     */
    public MemoryManageable remove(Object id) {
        MemoryManageable result = null;
        for (int i=0; i<10; ++i) {
	        //QueueListEntry entry = internalList.getFirstEntry();
        	QueueListEntry entry = prioritizedPackets[i].getFirstEntry();
	        try {
	            while (entry != null) {
	                MemoryManageable p = (MemoryManageable) entry.getElement();
	                if (p.getMemoryId().equals(id)) {
	                    result = p;
	                    remove(p);
	                    break;
	                }
	                //entry = internalList.getNextEntry(entry);
	                entry = prioritizedPackets[i].getNextEntry(entry);
	            }
	        }
	        catch (JMSException jmsEx) {
	            jmsEx.printStackTrace();
	        }
        }
        synchronized (inLock) {
            inLock.notify();
        }
        return result;
    }

    /**
     * remove any MemoryManageables in the queue
     */
    public void clear() {
        //while (!internalList.isEmpty()) {
    	for (int i=0; i<10; ++i) {
	    	while (!prioritizedPackets[i].isEmpty()) {
	            //MemoryManageable packet = (MemoryManageable) internalList.removeFirst();
	    		MemoryManageable packet = (MemoryManageable) prioritizedPackets[i].removeFirst();
	            decrementMemoryUsed(packet);
	        }
    	}
        synchronized (inLock) {
            inLock.notifyAll();
        }
    }

    /**
     * @return true if the queue is empty
     */
    public boolean isEmpty() {
        //return internalList.isEmpty();
    	for (int i=0; i<10; ++i) {
    		if (!prioritizedPackets[i].isEmpty()) return false;
    	}
    	return true;
    }

    /**
     * retrieve a MemoryManageable at an indexed position in the queue
     *
     * @param index
     * @return
     */
    public MemoryManageable get(int index) {
        //return (MemoryManageable) internalList.get(index);
    	throw new UnsupportedOperationException("Cannot invoke this method on a MemoryBoundedPrioritizedQueue instance");
    }

    /**
     * Retrieve a shallow copy of the contents as a list
     *
     * @return a list containing the bounded queue contents
     */
    public List getContents() {
        //Object[] array = internalList.toArray();
        List list = new ArrayList();
        for (int j=9; j>=0; --j) {
        	Object[] array = prioritizedPackets[j].toArray();
	        for (int i = 0; i < array.length; i++) {
	            list.add(array[i]);
	        }
        }
        return list;
    }

    private int getPacketPriority(MemoryManageable packet) {
    	int priority=DEFAULT_PRIORITY;
    	if (packet.getPriority()>=0 || packet.getPriority()<=9) {
    		priority = packet.getPriority();
    	}
    	return priority;
    }
}