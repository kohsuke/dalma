/**
 *
 * Copyright 2004 Protique Ltd
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 **/


package org.activemq.io.impl;
import java.io.DataOutput;
import java.io.IOException;
import org.activemq.message.BrokerInfo;
import org.activemq.message.Packet;

/**
 * Writes a ConsumerInfo object to a Stream
 */

public class BrokerInfoWriter extends AbstractPacketWriter {


    /**
     * Return the type of Packet
     *
     * @return integer representation of the type of Packet
     */

    public int getPacketType() {
        return Packet.ACTIVEMQ_BROKER_INFO;
    }

    /**
     * Write a Packet instance to data output stream
     *
     * @param packet  the instance to be seralized
     * @param dataOut the output stream
     * @throws IOException thrown if an error occurs
     */

    public void writePacket(Packet packet, DataOutput dataOut) throws IOException {
        super.writePacket(packet, dataOut);
        BrokerInfo info = (BrokerInfo) packet;
        super.writeUTF(info.getBrokerName(), dataOut);
        super.writeUTF(info.getClusterName(), dataOut);
        dataOut.writeLong(info.getStartTime());
        super.writeObject(info.getProperties(), dataOut);
        if (wireFormatVersion>=2){
            dataOut.writeBoolean(info.isRemote());
        }

    }


}
