package javax.jbi.messaging;

public interface Fault extends NormalizedMessage
{
    
}
