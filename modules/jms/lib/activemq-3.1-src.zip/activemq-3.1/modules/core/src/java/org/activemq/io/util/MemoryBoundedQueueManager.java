/** 
 * 
 * Copyright 2004 Protique Ltd
 * Copyright 2004 Hiram Chirino
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.io.util;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import EDU.oswego.cs.dl.util.concurrent.ConcurrentHashMap;

/**
 * A factory manager for MemoryBoundedQueue and also ensures that the maximum memory used by all active
 * MemoryBoundedQueues created by this instance stays within the memory usage bounds set.
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class MemoryBoundedQueueManager {
    
    private final ConcurrentHashMap activeQueues = new ConcurrentHashMap();
    private final MemoryBoundedObjectManager memoryManager;

    /**
     * @param name
     * @param maxSize
     */
    public MemoryBoundedQueueManager(MemoryBoundedObjectManager memoryManager) {
        this.memoryManager = memoryManager;        
    }

    /**
     * retrieve a named MemoryBoundedQueue or creates one if not found
     * 
     * @param name
     * @return an named instance of a MemoryBoundedQueue
     */
    public MemoryBoundedQueue getMemoryBoundedQueue(String name) {
        MemoryBoundedQueue result = (MemoryBoundedQueue) activeQueues.get(name);
        if (result == null) {
        	if (memoryManager.isSupportJMSPriority())
        		result = new MemoryBoundedPrioritizedQueue(this, name);
        	else
        		result = new MemoryBoundedQueue(this, name);
            activeQueues.put(name, result);
        }
        return result;
    }

    /**
     * close this queue manager and all associated MemoryBoundedQueues
     */
    public void close() {
        memoryManager.close();
    }

    /**
     * @return Returns the memoryManager.
     */
    public MemoryBoundedObjectManager getMemoryManager() {
        return memoryManager;
    }

    public int getCurrentCapacity() {
        return memoryManager.getCurrentCapacity();
    }

    public void add(MemoryBoundedQueue queue) {
        memoryManager.add(queue);
    }

    public void remove(MemoryBoundedQueue queue) {
        memoryManager.remove(queue);
        activeQueues.remove(queue.getName());
    }

    public boolean isFull() {
        return memoryManager.isFull();
    }

    public void incrementMemoryUsed(int size) {
        memoryManager.incrementMemoryUsed(size);
    }

    public void decrementMemoryUsed(int size) {
        memoryManager.decrementMemoryUsed(size);
    }    
    
    public List getMemoryBoundedQueues(){
        return new ArrayList(activeQueues.values());
    }
    
    public String dumpContents(){
        String result = "Memory = " + memoryManager.getTotalMemoryUsedSize() + " , capacity = " + memoryManager.getCurrentCapacity() + "\n";
        for (Iterator i = activeQueues.values().iterator(); i.hasNext(); ){
            MemoryBoundedQueue q = (MemoryBoundedQueue)i.next();
            result += "\t" + q.getName() + " enqueued = " + q.getContents().size() + " memory = " + q.getLocalMemoryUsedByThisQueue() + "\n";
        }
        result += "\n\n";
        return result;
    }
    
}
