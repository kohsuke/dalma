/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.io;
import java.io.DataInputStream;
import java.io.IOException;

import javax.jms.JMSException;

import org.activemq.io.impl.DefaultWireFormat;
import org.activemq.util.FactoryFinder;

/**
 * Represents a strategy of encoding packets on the wire or on disk using some kind of serialization or wire format.
 * <p/>We use a default efficient format for Java to Java communication but other formats to other systems can be used,
 * such as using simple text strings when talking to JavaScript or coming up with other formats for talking to C / C#
 * languages or proprietary messaging systems we wish to interface with at the wire level etc.
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class WireFormatLoader {
    private static FactoryFinder finder = new FactoryFinder("META-INF/services/org/activemq/io/");
    private WireFormat preferedWireFormat;

    /**
     * Default Constructor
     */
    public WireFormatLoader() {
        this(new DefaultWireFormat());
    }

    /**
     * Construct WireFormatLoader with the prefered WireFormat
     * 
     * @param prefered
     */
    public WireFormatLoader(WireFormat prefered) {
        this.preferedWireFormat = prefered;
    }

    /**
     * Create a wire format
     * 
     * @param dataIn
     * @return the WireFormat
     * @throws JMSException
     * @throws IOException
     */
    public WireFormat getWireFormat(DataInputStream dataIn) throws JMSException, IOException {
        WireFormat result = preferedWireFormat;
        dataIn.mark(10);
        int protocol = dataIn.read();
        if (protocol == 128) {
            //tis amqfast
            result = WireFormatLoader.getWireFormat("amqpfast");
        }
        dataIn.reset();
        return result;
    }

    /**
     * @return Returns the preferedWireFormat.
     */
    public WireFormat getPreferedWireFormat() {
        return preferedWireFormat;
    }

    /**
     * @param preferedWireFormat The preferedWireFormat to set.
     */
    public void setPreferedWireFormat(WireFormat preferedWireFormat) {
        this.preferedWireFormat = preferedWireFormat;
    }

    /**
     * load a WireFormat by name - e.g. 'default','amqpfast' etc.
     * 
     * @param format
     * @return the wire format
     * @throws JMSException
     */
    public static WireFormat getWireFormat(String format) throws JMSException {
        try {
            Object value = finder.newInstance(format);
            if (value instanceof WireFormat) {
                return (WireFormat) value;
            }
            else {
                throw new JMSException(format + " is not a WireFormat: " + value);
            }
        }
        catch (IllegalAccessException e) {
            throw createJMSexception(format, e);
        }
        catch (InstantiationException e) {
            throw createJMSexception(format, e);
        }
        catch (IOException e) {
            throw createJMSexception(format, e);
        }
        catch (ClassNotFoundException e) {
            throw createJMSexception(format, e);
        }
    }

    protected static JMSException createJMSexception(String protocol, Exception e) {
        JMSException answer = new JMSException("Could not load protocol: " + protocol + ". Reason: " + e);
        answer.setLinkedException(e);
        return answer;
    }
}