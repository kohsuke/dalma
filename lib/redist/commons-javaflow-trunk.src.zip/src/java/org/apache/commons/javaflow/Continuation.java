/*
 * Copyright 1999-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.javaflow;

import java.io.Serializable;
import org.apache.commons.javaflow.bytecode.StackRecorder;
import org.apache.commons.javaflow.utils.ReflectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * Snapshot of a thread execution state.
 *
 * <p>
 * A {@link Continuation} object is an immutable object that captures everything in
 * the Java stack. This includes
 * (1) current instruction pointer,
 * (2) return addresses, and
 * (3) local variables.
 *
 * <p>
 * <tt>Continuation</tt> objects are used to restore the captured execution states
 * later.
 *
 * @author <a href="mailto:stephan@apache.org">Stephan Michels</a>
 * @author <a href="mailto:tcurdt@apache.org">Torsten Curdt</a>
 * @version CVS $Id: Continuation.java 320947 2005-10-13 23:44:08Z tcurdt $
 */
public final class Continuation implements Serializable {

    private final static Log log = LogFactory.getLog(Continuation.class);
    
    private final StackRecorder stack;

    private static final long serialVersionUID = 1L;

    
    /**
     * Create a new continuation, which continue a previous continuation.
     */
    private Continuation(StackRecorder sr) {
        stack = sr;
    }


    /**
     * get the current context.
     *
     * <p>
     * This method returns the same context object given to {@link #startWith(Runnable, Object)}
     * or {@link #continueWith(Continuation, Object)}.
     *
     * <p>
     * A different context can be used for each run of a continuation, so
     * this mechanism can be used to associate some state with each execution.
     *
     * @return
     *      null if this method is invoked outside {@link #startWith(Runnable, Object)}
     *      or {@link #continueWith(Continuation, Object)} .
     */
    public static Object getContext() {
        return StackRecorder.get().getContext();
    }

    /**
     * Creates a new {@link Continuation} object from the specified {@link Runnable}
     * object.
     *
     * <p>
     * Unlike the {@link #startWith(Runnable)} method, this method doesn't actually
     * execute the <tt>Runnable</tt> object. It will be executed when
     * it's {@link #continueWith(Continuation) continued}.
     * 
     * @return
     *      always return a non-null valid object.
     */
    public static Continuation startSuspendedWith( final Runnable target ) {
        return new Continuation(new StackRecorder(target));
    }

    /**
     * Starts executing the specified {@link Runnable} object in an environment
     * that allows {@link Continuation#suspend()}.
     *
     * <p>
     * This is a short hand for <tt>startWith(target,null)</tt>.
     *
     * @see #startWith(Runnable, Object).
     */
    public static Continuation startWith( final Runnable target ) {
        return startWith(target,null);
    }

    /**
     * Starts executing the specified {@link Runnable} object in an environment
     * that allows {@link Continuation#suspend()}.
     *
     * This method blocks until the continuation suspends or completes.
     *
     * @param target
     *      The object whose <tt>run</tt> method will be executed.
     * @param context
     *      This value can be obtained from {@link #getContext()} until this method returns.
     *      Can be null.
     * @return
     *      If the execution completes and there's nothing more to continue, return null.
     *      Otherwise, the execution has been {@link #suspend() suspended}, in which case
     *      a new non-null continuation is returned.
     * @see #getContext()
     */
    public static Continuation startWith( final Runnable target, final Object context ) {
        if(target==null) {
            throw new IllegalArgumentException("target is null");
        }

        log.debug("starting new flow from " + ReflectionUtils.getClassName(target) + "/" + ReflectionUtils.getClassLoaderName(target));

        return execute(new StackRecorder(target), context);
    }

    /**
     * Resumes the execution of the specified continuation from where it's left off.
     *
     * <p>
     * This is a short hand for <tt>continueWith(resumed,null)</tt>.
     *
     * @see #continueWith(Continuation, Object)
     */
    public static Continuation continueWith(final Continuation resumed) {
        return continueWith(resumed,null);
    }

    /**
     * Resumes the execution of the specified continuation from where it's left off.
     *
     * This method blocks until the continuation suspends or completes.
     *
     * @param resumed
     *      The resumed continuation to be executed. Must not be null.
     * @param context
     *      This value can be obtained from {@link #getContext()} until this method returns.
     *      Can be null.
     * @return
     *      If the execution completes and there's nothing more to continue, return null.
     *      Otherwise, the execution has been {@link #suspend() suspended}, in which case
     *      a new non-null continuation is returned.
     * @see #getContext()
     */
    public static Continuation continueWith(final Continuation resumed, final Object context) {
        if(resumed==null) {
            throw new IllegalArgumentException("continuation parameter must not be null.");
        }

        log.debug("continueing with continuation " + ReflectionUtils.getClassName(resumed) + "/" + ReflectionUtils.getClassLoaderName(resumed));

        return execute(new StackRecorder(resumed.stack),context);
    }

    private static Continuation execute(StackRecorder stack, final Object context) {
        stack = stack.execute(context);
        if(stack==null) {
            return null;
        } else {
            return new Continuation(stack);
        }
    }

    public boolean isSerializable() {
        return stack.isSerializable();
    }
    
    /**
     * Stops the running continuation.
     *
     * <p>
     * This method can be only called inside {@link #continueWith} or {@link #startWith} methods.
     * When called, the thread returns from the above methods with a new {@link Continuation}
     * object that captures the thread state.
     *
     * @throws IllegalStateException
     *      if this method is called outside the {@link #continueWith} or {@link #startWith} methods.
     */
    public static void suspend() {
        StackRecorder.suspend();
    }

    public String toString() {
        return "Continuation@" + hashCode() + "/" + ReflectionUtils.getClassLoaderName(this);
    }
}
