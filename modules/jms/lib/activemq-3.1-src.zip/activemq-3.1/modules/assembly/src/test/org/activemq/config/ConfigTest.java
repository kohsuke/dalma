/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.config;

import junit.framework.TestCase;
import org.activemq.XmlConfigHelper;
import org.activemq.ActiveMQPrefetchPolicy;
import org.activemq.broker.Broker;
import org.activemq.broker.BrokerContainer;
import org.activemq.broker.BrokerContainerFactory;
import org.activemq.broker.BrokerContext;
import org.activemq.broker.impl.BrokerConnectorImpl;
import org.activemq.security.SecurityAdapter;
import org.activemq.service.RedeliveryPolicy;
import org.activemq.spring.ActiveMQBeanDefinitionReader;
import org.activemq.spring.ActiveMQBeanFactory;
import org.activemq.spring.ActiveMQDtdResolver;
import org.activemq.spring.SpringBrokerContainerFactory;
import org.activemq.transport.DiscoveryAgent;
import org.activemq.transport.NetworkChannel;
import org.activemq.transport.NetworkConnector;
import org.activemq.transport.TransportServerChannel;
import org.activemq.transport.multicast.MulticastDiscoveryAgent;
import org.activemq.transport.tcp.TcpTransportServerChannel;
import org.activemq.transport.vm.VmTransportServerChannel;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.w3c.dom.Document;

import javax.jms.JMSException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.File;
import java.util.List;
import java.net.URI;

/**
 * @version $Revision: 1.2 $
 */
public class ConfigTest extends TestCase {
    public void testConfig() throws Exception {
        ActiveMQBeanFactory factory = new ActiveMQBeanFactory("Cheese", new ClassPathResource("org/activemq/config/example.xml"));

        Object value = factory.getBean("broker");

        assertTrue("Should have created a broker!", value != null);
        assertTrue("Should be a broker container: " + value, value instanceof BrokerContainer);

        BrokerContainer container = (BrokerContainer) value;
        Broker broker = container.getBroker();
        assertTrue("Should have a broker!", broker != null);

        assertEquals("Broker name not set!", "localhost", broker.getBrokerName());

        Object transport = factory.getBean("transport");
        assertTrue("Made transport", transport != null);

        List connectors = container.getTransportConnectors();
        assertEquals("Should have created more connectors", 3, connectors.size());

        BrokerConnectorImpl connector1 = (BrokerConnectorImpl) connectors.get(0);
        TransportServerChannel serverChannel1 = connector1.getServerChannel();
        assertTrue(serverChannel1 instanceof VmTransportServerChannel);

        BrokerConnectorImpl connector2 = (BrokerConnectorImpl) connectors.get(1);
        TransportServerChannel serverChannel2 = connector2.getServerChannel();
        assertTrue(serverChannel2 instanceof TcpTransportServerChannel);
        TcpTransportServerChannel tcpChannel2 = (TcpTransportServerChannel) serverChannel2;
        assertEquals("backlog", 1000, tcpChannel2.getBacklog());
        assertEquals("maxOutstandingMessages", 50, tcpChannel2.getMaxOutstandingMessages());
        assertTrue("useAsyncSend", tcpChannel2.isUseAsyncSend());
        assertTrue("Created correct wireFormat: " + tcpChannel2.getWireFormat(), tcpChannel2.getWireFormat() instanceof WireFormatStub);


        List networkConnectors = container.getNetworkConnectors();
        assertEquals("Should have a single network connector", 1, networkConnectors.size());
        NetworkConnector networkConnector = (NetworkConnector) networkConnectors.get(0);
        ActiveMQPrefetchPolicy localPrefetchPolicy = networkConnector.getLocalPrefetchPolicy();
        assertNotNull("localPrefetchPolicy", localPrefetchPolicy);
        assertEquals("localPrefetchPolicy.getQueuePrefetch", 1, localPrefetchPolicy.getQueuePrefetch());
        assertEquals("localPrefetchPolicy.getQueueBrowserPrefetch", 2, localPrefetchPolicy.getQueueBrowserPrefetch());

        ActiveMQPrefetchPolicy remotePrefetchPolicy = networkConnector.getRemotePrefetchPolicy();
        assertNotNull("remotePrefetchPolicy", remotePrefetchPolicy);
        assertEquals("remotePrefetchPolicy.getTopicPrefetch", 3, remotePrefetchPolicy.getTopicPrefetch());
        assertEquals("remotePrefetchPolicy.getDurableTopicPrefetch", 4, remotePrefetchPolicy.getDurableTopicPrefetch());


        List networkChannels = networkConnector.getNetworkChannels();
        assertEquals("Should have 2 network channels", 2, networkChannels.size());

        NetworkChannel networkChannel = (NetworkChannel) networkChannels.get(0);
        assertEquals("URL not equal", "tcp://somehost:61616", networkChannel.getUri());
        assertEquals("remoteUserName", "James", networkChannel.getRemoteUserName());
        assertEquals("remotePassword", "Stewey", networkChannel.getRemotePassword());

        System.out.println("Created network channel: " + networkChannel);

        SecurityAdapter securityAdapter = broker.getSecurityAdapter();
        assertTrue("Should have created a security adapter", securityAdapter != null);

        RedeliveryPolicy redeliveryPolicy = broker.getRedeliveryPolicy();
        assertTrue("Should have created a redeliveryPolicy", redeliveryPolicy != null);
        assertEquals("isBackOffMode", true, redeliveryPolicy.isBackOffMode());
        assertEquals("getMaximumRetryCount", 10, redeliveryPolicy.getMaximumRetryCount());

        DiscoveryAgent discoveryAgent = container.getDiscoveryAgent();
        assertTrue("Have a discovery agent: " + discoveryAgent, discoveryAgent instanceof MulticastDiscoveryAgent);
        MulticastDiscoveryAgent multicastAgent = (MulticastDiscoveryAgent) discoveryAgent;
        assertEquals("getKeepAliveTimeout", 1000, multicastAgent.getKeepAliveTimeout());
        assertEquals("getChannelName", "cheese", multicastAgent.getChannelName());
        assertEquals("getUri", new URI("multicast://228.8.9.10:2677"), multicastAgent.getUri());
    }

    public void testJournalConfig() throws JMSException {
        File file = new File("target/data/journal");
        recursiveDelete(file);        
        createBroker(new FileSystemResource("src/sample-conf/journal-example.xml"));
        assertTrue("Created the file for the persistent store: " + file, file.exists());
    }

    private static void recursiveDelete(File file) {
        if( file.isDirectory() ) {
            File[] files = file.listFiles();
            for (int i = 0; i < files.length; i++) {
                recursiveDelete(files[i]);              
            }
        }
        file.delete();
    }

	public void testVmConfig() throws JMSException {
        createBroker(new FileSystemResource("src/sample-conf/vm-example.xml"));
    }

    public void testTransform() throws Exception {
        ClassPathResource resource = new ClassPathResource("org/activemq/activemq-to-spring.xsl");
        StreamSource source = new StreamSource(resource.getInputStream(), resource.getURL().toString());
        Transformer transformer = ActiveMQBeanDefinitionReader.createTransformer(source);

        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        builder.setEntityResolver(new ActiveMQDtdResolver());
        Document document = builder.parse(new ClassPathResource("org/activemq/config/example.xml").getFile());

        transformer.transform(new DOMSource(document), new StreamResult(new File("target/example-spring.xml")));
    }

    public void testSpring() throws Exception {
        XmlBeanFactory factory = new XmlBeanFactory(new ClassPathResource("org/activemq/config/spring-test.xml"));

        Object transport = factory.getBean("transport");
        assertTrue("Made transport", transport != null);

        System.out.println("Created transport: " + transport);
    }

    public void testXmlConfigHelper() throws Exception {
        createBroker("file:src/sample-conf/vm-example.xml");
        createBroker("org/activemq/config/config.xml");
    }

    protected BrokerContainer createBroker(String resource) throws JMSException {
        BrokerContainerFactory factory = XmlConfigHelper.createBrokerContainerFactory(resource);
        return createBroker(factory);
    }

    protected BrokerContainer createBroker(Resource resource) throws JMSException {
        SpringBrokerContainerFactory factory = new SpringBrokerContainerFactory();
        factory.setResource(resource);
        return createBroker(factory);

    }

    protected BrokerContainer createBroker(BrokerContainerFactory factory) throws JMSException {
        assertTrue("Factory is null", factory != null);
        String brokerName = getName();
        BrokerContainer container = factory.createBrokerContainer(brokerName, BrokerContext.getInstance());

        assertTrue("Should have a broker container!", container != null);

        Broker broker = container.getBroker();
        assertTrue("Should have a broker!", broker != null);

        assertEquals("Broker name not set!", brokerName, broker.getBrokerName());

        container.start();
        container.stop();
        return container;
    }
}
