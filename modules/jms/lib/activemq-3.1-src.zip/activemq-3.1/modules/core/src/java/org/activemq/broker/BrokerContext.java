/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/
package org.activemq.broker;

import EDU.oswego.cs.dl.util.concurrent.ConcurrentHashMap;

import javax.jms.JMSException;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import java.util.Iterator;

/**
 * A cache of all the brokers and broker connectors in use which is usually used
 * in a singleton way but could be used in an IoC style manner.
 *
 * @version $Revision: 1.1.1.1 $
 */
public class BrokerContext {

    private static final BrokerContext singleton = new BrokerContext();

    private Map brokersByName = new ConcurrentHashMap();
    private Map connectorsByURL = new ConcurrentHashMap();

    public static BrokerContext getInstance() {
        return singleton;
    }


    public synchronized BrokerContainer getBrokerContainerByName(String url, String name, BrokerContainerFactory factory) throws JMSException {
        BrokerContainer container = (BrokerContainer) brokersByName.get(url);
        if (container == null) {
            // this should register the container
            container = factory.createBrokerContainer(name, this);

            // note that we will register the broker by name and by URL
            brokersByName.put(url, container);

            assert brokersByName.get(url) == container : "Should have registered the container by now";

            container.start();
        }
        return container;
    }

    public void registerContainer(String url, BrokerContainer container) {
        if (url == null) {
            throw new IllegalArgumentException("Name must not be null");
        }
        brokersByName.put(url, container);
    }

    public void deregisterContainer(String url, BrokerContainer container) {
        brokersByName.remove(url);

        // we may have registered the container under an alias, so lets remove it as any value
        List list = new ArrayList();
        for (Iterator iter = brokersByName.entrySet().iterator(); iter.hasNext(); ) {
            Map.Entry entry = (Map.Entry) iter.next();
            Object key = entry.getKey();
            Object value = entry.getValue();
            if (container.equals(value)) {
                list.add(key);
            }
        }

        for (Iterator iter = list.iterator(); iter.hasNext();) {
            Object key = iter.next();
            brokersByName.remove(key);
        }
    }

    public void registerConnector(String url, BrokerConnector connector) {
        connectorsByURL.put(url, connector);
    }

    public void deregisterConnector(String urlString) {
        connectorsByURL.remove(urlString);
    }

    public BrokerConnector getConnectorByURL(String url) {
        BrokerConnector brokerConnector = (BrokerConnector) connectorsByURL.get(url);
        if (brokerConnector == null) {
            if (url.startsWith("reliable:")) {
                return getConnectorByURL(url.substring("reliable:".length()));
            }
            else if (url.startsWith("list:")) {
                return getConnectorByURL(url.substring("list:".length()));
            }else if (url.startsWith("peer:")){
                return getConnectorByURL(url.substring("peer:".length()));
            }
        }
        return brokerConnector;
    }
}
