/** 
 * 
 * Copyright 2004 Protique Ltd
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); 
 * you may not use this file except in compliance with the License. 
 * You may obtain a copy of the License at 
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, 
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
 * See the License for the specific language governing permissions and 
 * limitations under the License. 
 * 
 **/

package org.activemq.io.util;
/**
 * Compression stream
 * 
 * @version $Revision: 1.1.1.1 $
 */
public class ByteArrayFragmentation {
    /**
     * Data size above which fragmentation will be used
     */
    public static final int DEFAULT_FRAGMENTATION_LIMIT = 64 * 1024;
    private int fragmentationLimit = DEFAULT_FRAGMENTATION_LIMIT;

    /**
     * @return Returns the fragmentationLimit.
     */
    public int getFragmentationLimit() {
        return fragmentationLimit;
    }

    /**
     * @param fragmentationLimit The fragmentationLimit to set.
     */
    public void setFragmentationLimit(int fragmentationLimit) {
        this.fragmentationLimit = fragmentationLimit;
    }

    /**
     * @param ba
     * @return true if fragmentation will be applied
     */
    public boolean doFragmentation(ByteArray ba) {
        return ba != null && ba.getLength() > fragmentationLimit;
    }

    /**
     * Fragment a ByteArray into a number of parts
     * 
     * @param ba
     * @return
     */
    public ByteArray[] fragment(ByteArray ba) {
        ByteArray[] answer = null;
        if (ba != null) {
            if (doFragmentation(ba)) {
                //find out how many parts
                int bytesRemaining = ba.getLength();
                int numberOfParts = bytesRemaining / fragmentationLimit;
                answer = new ByteArray[numberOfParts];
                int partLength = ba.getLength() / numberOfParts + 1;
                byte[] buffer = ba.getBuf();
                int offset = ba.getOffset();
                int count = 0;
                while (bytesRemaining > 0) {
                    answer[count] = new ByteArray(buffer, offset, partLength);
                    bytesRemaining -= partLength;
                    offset += partLength;
                    partLength = partLength < bytesRemaining ? partLength : bytesRemaining;
                    count++;
                }
            }
            else {
                answer = new ByteArray[]{ba};
            }
        }
        return answer;
    }

    /**
     * Assemble a ByteArray from an array of fragements
     * 
     * @param array
     * @return
     */
    public ByteArray assemble(ByteArray[] array) {
        ByteArray answer = new ByteArray();
        if (array != null) {
            //get the length to assemble;
            int length = 0;
            for (int i = 0;i < array.length;i++) {
                length += array[i].getLength();
            }
            byte[] data = new byte[length];
            int offset = 0;
            for (int i = 0;i < array.length;i++) {
                System.arraycopy(array[i].getBuf(), array[i].getOffset(), data, offset, array[i].getLength());
                offset += array[i].getLength();
                answer.reset(data);
            }
        }
        return answer;
    }
}