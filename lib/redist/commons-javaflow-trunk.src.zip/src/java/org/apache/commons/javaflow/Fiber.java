/*
 * Copyright 1999-2004 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.javaflow;

import java.lang.reflect.Method;
import java.io.Serializable;

/**
 * A virtual "thread".
 *
 * <p>
 * A fiber to a thread is like a thread to a CPU.
 *
 * <p>
 * Fibers can emulate multiple independent execution flows on a single
 * (or possibly multiple) thread(s), just like threads emulate multple
 * independent execution flows on a single (or possibly multiple) CPU(s).
 *
 * <p>
 * The biggest difference between a fiber and a thread is in
 * its pre-emptiveness. Whereas a thread loses a CPU involuntarily (or
 * even without noticing), a fiber loses a thread only when it
 * {@link #yield() yields}.
 *
 * <p>
 * Another difference is that a fiber is fully implemented at Java level.
 * This allows you to stop a fiber and resume it later, execute it
 * on another thread, or even move it to another JVM, by using
 * serialization.
 *
 *
 *
 *
 *
 *
 * <h2>Usage</h2>
 * <p>
 * A fiber goes through the state transition much similar to that of {@link Thread}.
 * First, a {@link Fiber} gets created:
 *
 * <pre>
 * Fiber f = new Fiber(myRunnable);
 * </pre>
 *
 * <p>
 * Then it is started:
 *
 * <pre>
 * f.start();
 * </pre>
 *
 * <p>
 * At this point, a fiber is said to be {@link #isAlive() alive}.
 * The {@link Runnable#run()} method of <tt>myRunnable</tt> starts
 * executing by using the same thread. This execution continues until the fiber
 * yields or exits from the {@link Runnable#run()} method. When either of those
 * conditions are met, the thread used to run a fiber returns from the <tt>start</tt> method.
 *
 * <p>
 * The caller of the <tt>start</tt> method can then go on to do
 * some other things. Later, a fiber can be continued as follows:
 *
 * <pre>
 * f._continue();
 * </pre>
 *
 * <p>
 * At this point, a fiber resumes its execution from where it left off
 * before, again by using the same thread. Just like with
 * the <tt>start</tt> method, this execution continues until
 * the fiber yields or exits, and then the thread used to run a fiber
 * returns from the <tt>_continue</tt> method.
 *
 * <p>
 * Typically, the <tt>_continue</tt> method needs to be called repeatedly
 * for a fiber to complete its execution. Therefore, the simplest
 * execution loop would look like this:
 *
 * <pre>
 * while(f.isAlive())
 *     f._continue();
 * </pre>
 *
 *
 *
 *
 * <h2>Fiber Migration</h2>
 * <p>
 * A fiber is not tied to any particular thread. Therefore, it can be
 * started on one thread, then continued on another thread, and then
 * continued on yet another thread, and so on.
 *
 * This migration can happen while a fiber is not {@link #isExecuting() executing}.
 *
 * <p>
 * If all objects in a fiber's stack frames are {@link Serializable},
 * then a fiber can be serialized. This allows a fiber to be migrated
 * to another JVM. Note that for this to work correctly, all methods on
 * a fiber's stack frames must be exactly the same between two JVMs,
 * or else unpredictable behaviors will occur.
 *
 *
 * @author Kohsuke Kawaguchi
 */
public class Fiber implements Runnable, Serializable, Cloneable {

    private /*final*/ Runnable target;

    private Continuation continuation;

    private boolean started = false;

    private boolean executing = false;

    private static final ThreadLocal runningFibers = new ThreadLocal();

    /**
     * Creates a new {@link Fiber} that runs its {@link #run()} method
     * when started.
     */
    protected Fiber() {
        target = this;
    }

    /**
     * Creates a new {@link Fiber} that runs the {@link Runnable#run()} method
     * of the specified instance when started.
     */
    public Fiber(Runnable target) {
        this.target = target;
    }

    /**
     * Begins the execution of this fiber.
     *
     * <p>
     * Unlike normal thread, this method blocks until the fiber {@link #yield() yields}
     * or completes.
     *
     * @throws IllegalStateException
     *      if this fiber has already been started.
     */
    public void start() {
        if(started) {
            throw new IllegalStateException("the fiber is already started");
        }
        started = true;
        executing = true;
        Fiber old = (Fiber)runningFibers.get();
        try {
            runningFibers.set(this);
            continuation = Continuation.startWith(this);
        } finally {
            runningFibers.set(old);
            executing = false;
        }
    }

    /**
     * Resumes the execution of this fiber.
     *
     * <p>
     * This is analogous to the thread resume operation. The fiber will pick up
     * execution from where it {@link #yield() yielded} last time.
     *
     * This method blocks until the fiber {@link #yield() yields} or completes.
     */
    public void _continue() {
        if(!isAlive()) {
            throw new IllegalStateException("the fiber has already completed");
        }
        if(executing) {
            throw new IllegalStateException("the fiber is already executing");
        }
        executing = true;

        Fiber old = (Fiber)runningFibers.get();
        try {
            runningFibers.set(this);
            continuation = Continuation.continueWith(continuation);
        } finally {
            runningFibers.set(old);
            executing = false;
        }
    }

    /**
     * Causes the currently runnning fiber to pause.
     *
     * This method stores the state of the execution on side and then
     * return from the {@link #start()} or {@link #_continue()} methods.
     *
     * @throws IllegalStateException
     *      unless this method is called from a fiber.
     */
    public static void yield() {
        Continuation.suspend();
    }

    /**
     * Creates an exact replica of this fiber.
     *
     * <p>
     * A fiber can be forked when it's not executing. If this fiber
     * has yielded at execution point A, then the newly created fiber
     * returned from this method will resume its execution from A.
     * In a way, this is similar to Unix process fork.
     *
     * <p>
     * objects on this fiber's stack frames aren't cloned, so two
     * fibers will refer to the same objects. Alternatively, serialization
     * can be also used to perform a deep-copy of a fiber.
     *
     * <p>
     * A fiber can be forked when it's not started yet, or when it's completed.
     *
     * @return
     *      always return a non-null valid {@link Fiber} object.
     *
     * @throws IllegalStateException
     *      if this fiber is executing.
     */
    public Fiber fork() {
        if(executing) {
            throw new IllegalStateException("cannot fork an executing fiber");
        }

        try {
            return (Fiber)clone();
        } catch (CloneNotSupportedException e) {
            // we implement Cloneable on Fiber, so this is impossible
            throw new Error(e);
        }
    }

    /**
     * Returns true if this fiber is still alive.
     *
     * A fiber is alive if it has been started but not yet died.
     * In particular, a fiber is alive even when it's not executing
     * on a thread.
     */
    public final boolean isAlive() {
        return continuation!=null;
    }

    /**
     * Returns true if this fiber is currently executing on a thread.
     */
    public final boolean isExecuting() {
        return executing;
    }

    /**
     * Should be overidden the derived classes to describe the code
     * that executes when the fiber runs.
     *
     * <p>
     * If this object is constructed with the {@link #Fiber(Runnable)} method,
     * it runs the <tt>run</tt> method of the specified <tt>Runnable</tt> object. Otherwise
     * report an error.
     */
    public void run() {
        if (target != null) {
            target.run();
       } else {
            throw new IllegalStateException(
                "This is most likely a mistake. You should either specify a Runnable object " +
                "as a constructor parameter, or you should override the run method.");
        }
    }

    /**
     * Gets the currently executing fiber.
     *
     * <p>
     * This method works like {@link Thread#currentThread()}.
     *
     * @return
     *      null if no fiber is executing (IOW, if this method is called from outside
     *      a fiber.) Otherwise non-null valid fiber.
     */
    public static Fiber currentFiber() {
        Fiber f = (Fiber)runningFibers.get();
        if(!f.isExecuting())
            throw new Error("a bug in javaflow");
        return f;
    }

    private static final long serialVersionUID = 1L;
}
